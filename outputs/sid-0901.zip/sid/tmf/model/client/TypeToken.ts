export interface TypeToken {
  type?: Type;
}
