export interface EntityUtil {
}
