export interface Error {
  code?: string;
  reason?: string;
  message?: string;
  status?: string;
  referenceError?: string;
}
