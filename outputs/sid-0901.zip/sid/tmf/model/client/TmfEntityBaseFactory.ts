export interface TmfEntityBaseFactory {
  type?: final Class<T>;
  hrefURI?: string;
}
