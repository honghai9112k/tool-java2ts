export interface ApiCore {
  client?: final OkHttpClient;
  baseUri?: string;
  entityClass?: AbstractEntity;
  objectMapper?: final ObjectMapper;
  clazz?: Class<T>;
}
