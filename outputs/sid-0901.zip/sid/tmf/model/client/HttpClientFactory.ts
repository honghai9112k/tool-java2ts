export interface HttpClientFactory {
}
