export interface UriEntity {
}
