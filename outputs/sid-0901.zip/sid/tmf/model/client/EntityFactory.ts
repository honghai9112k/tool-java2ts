export interface EntityFactory {
  baseUrl?: static String;
}
