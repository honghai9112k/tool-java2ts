export interface EntityClient {
}
