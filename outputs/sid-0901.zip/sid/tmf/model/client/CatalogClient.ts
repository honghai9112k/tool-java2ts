export interface CatalogClient {
}
