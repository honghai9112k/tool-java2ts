export interface UriConstant {
}
