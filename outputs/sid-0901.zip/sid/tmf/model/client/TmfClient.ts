export interface TmfClient {
  clazz?: Class<T>;
}
