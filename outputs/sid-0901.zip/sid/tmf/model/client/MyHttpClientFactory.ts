export interface MyHttpClientFactory {
}
