export interface ImpactedBucket extends AbstractEntity {
  confirmationDate?: Date;
  requestedDate?: Date;
  amountAfter?: Quantity;
  amountBefore?: Quantity;
  bucket?: EntityRef;
  item?: ImpactedBucketItem[];
}
