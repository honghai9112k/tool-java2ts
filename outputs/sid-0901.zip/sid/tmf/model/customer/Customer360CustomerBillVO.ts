export interface Customer360CustomerBillVO extends AbstractEntity {
  category?: string;
  billNo?: string;
  state?: string;
}
