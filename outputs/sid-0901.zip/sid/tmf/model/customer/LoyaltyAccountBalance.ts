export interface LoyaltyAccountBalance extends AbstractEntity {
  amount?: Money;
  balanceType?: string;
}
