export interface Quote extends AbstractEntity {
  expectedQuoteCompletionDate?: Date;
  note?: Note[];
  contactMedium?: ContactMedium[];
  agreement?: EntityRef[];
  requestedQuoteCompletionDate?: Date;
  expectedFulfillmentStartDate?: Date;
  productOfferingQualification?: EntityRef[];
  externalId?: ExternalIdentifier[];
  billingAccount?: EntityRef[];
  relatedParty?: RelatedParty[];
  relatedOpportunity?: EntityRef;
  creationDate?: Date;
  authorization?: Authorization[];
  effectiveQuoteCompletionDate?: Date;
  quoteTotalPrice?: QuotePrice[];
  quoteItem?: QuoteItem[];
  state?: string;
  category?: string;
  instantSyncQuote?: boolean;
}
