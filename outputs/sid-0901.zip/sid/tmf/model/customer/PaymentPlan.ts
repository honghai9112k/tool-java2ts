export interface PaymentPlan extends AbstractEntity {
  numberOfPayments?: number;
  totalAmount?: Money;
  planType?: string;
  paymentMethod?: EntityRef;
  paymentFrequency?: string;
  priority?: number;
  status?: string;
}
