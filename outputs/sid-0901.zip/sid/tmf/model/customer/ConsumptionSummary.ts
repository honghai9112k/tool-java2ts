export interface ConsumptionSummary extends BucketCounter {
}
