export interface BillFormatRefOrValue extends EntityRefOrValue {
}
