export interface BillingCycleSpecificationRefOrValue extends EntityRefOrValue {
}
