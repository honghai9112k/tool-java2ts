export interface Customer360QuoteVO extends AbstractEntity {
  effectiveQuoteCompletionDate?: Date;
  expectedQuoteCompletionDate?: Date;
  expectedFulfillmentStartDate?: Date;
  state?: string;
  category?: string;
}
