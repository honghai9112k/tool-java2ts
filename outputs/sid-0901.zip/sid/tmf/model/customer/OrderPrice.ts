export interface OrderPrice extends AbstractEntity {
  unitOfMeasure?: string;
  price?: Price;
  priceType?: string;
  productOfferingPrice?: EntityRef;
  recurringChargePeriod?: string;
  billingAccount?: EntityRef;
  priceAlteration?: PriceAlteration[];
}
