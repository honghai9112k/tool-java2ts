export interface OrderItemRelationship extends EntityRel {
  code?: string;
}
