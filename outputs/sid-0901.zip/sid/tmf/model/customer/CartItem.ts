export interface CartItem extends AbstractEntity {
  itemTerm?: CartTerm[];
  note?: Note[];
  product?: Product;
  quantity?: number;
  productOffering?: EntityRef;
  itemTotalPrice?: CartPrice[];
  action?: string;
  cartItemRelationship?: CartItemRelationship[];
  itemPrice?: CartPrice[];
  cartItem?: CartItem[];
  status?: string;
}
