export interface ImpactedBucketItem extends AbstractEntity {
  itemType?: string;
  reason?: string;
  amount?: Quantity;
}
