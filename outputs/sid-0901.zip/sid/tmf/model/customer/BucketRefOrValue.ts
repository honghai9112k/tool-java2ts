export interface BucketRefOrValue extends EntityRefOrValue {
}
