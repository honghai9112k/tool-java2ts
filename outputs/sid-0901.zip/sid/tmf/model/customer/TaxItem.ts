export interface TaxItem extends AbstractEntity {
  taxAmount?: Money;
  taxRate?: number;
  taxCategory?: string;
}
