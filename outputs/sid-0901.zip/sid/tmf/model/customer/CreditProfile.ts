export interface CreditProfile extends AbstractEntity {
  creditProfileDate?: Date;
  creditRiskRating?: number;
  creditScore?: number;
}
