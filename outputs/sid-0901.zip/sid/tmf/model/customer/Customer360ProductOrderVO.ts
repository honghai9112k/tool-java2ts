export interface Customer360ProductOrderVO extends AbstractEntity {
  externalId?: string;
  completionDate?: Date;
  expectedCompletionDate?: Date;
  state?: string;
  category?: string;
  creationDate?: Date;
  priority?: string;
}
