export interface QuoteItemRelationship extends EntityRel {
  code?: string;
}
