export interface OrderRelationship extends EntityRel {
  code?: string;
}
