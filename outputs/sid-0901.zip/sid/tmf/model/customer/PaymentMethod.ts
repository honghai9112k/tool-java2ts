export interface PaymentMethod extends AbstractEntity {
  isPreferred?: boolean;
  authorizationCode?: string;
  status?: string;
  statusDate?: Date;
  statusReason?: string;
  account?: EntityRef[];
  relatedParty?: RelatedParty;
  relatedPlace?: RelatedPlace;
}
