export interface BucketCounter extends AbstractEntity {
  consumptionPeriod?: TimePeriod;
  level?: string;
  valueName?: string;
  counterType?: string;
  user?: EntityRef;
  value?: Quantity;
  characteristic?: Characteristic[];
}
