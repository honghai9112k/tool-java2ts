export interface ShoppingCart extends AbstractEntity {
  contactMedium?: ContactMedium[];
  cartTotalPrice?: CartPrice[];
  relatedParty?: RelatedParty[];
  creationDate?: Date;
  cartItem?: CartItem[];
}
