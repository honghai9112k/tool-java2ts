export interface Payment extends AbstractEntity {
  authorizationCode?: string;
  correlatorId?: string;
  paymentDate?: Date;
  status?: string;
  statusDate?: Date;
  account?: EntityRef;
  amount?: Money;
  channel?: EntityRef;
  payer?: RelatedParty;
  paymentItem?: PaymentItem[];
  paymentMethod?: PaymentMethodRefOrValue;
  taxAmount?: Money;
  totalAmount?: Money;
}
