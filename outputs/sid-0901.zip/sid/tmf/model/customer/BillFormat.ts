export interface BillFormat extends AbstractEntity {
}
