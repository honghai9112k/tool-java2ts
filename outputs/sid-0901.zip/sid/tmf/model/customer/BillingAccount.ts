export interface BillingAccount extends PartyAccount {
  ratingType?: string;
}
