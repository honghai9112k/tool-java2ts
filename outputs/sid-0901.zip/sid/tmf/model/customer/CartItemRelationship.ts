export interface CartItemRelationship extends EntityRel {
  code?: string;
}
