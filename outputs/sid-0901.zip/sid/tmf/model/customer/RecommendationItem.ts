export interface RecommendationItem extends AbstractEntity {
  priority?: number;
  product?: EntityRef;
  productOffering?: EntityRef;
}
