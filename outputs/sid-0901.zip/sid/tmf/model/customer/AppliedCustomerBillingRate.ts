export interface AppliedCustomerBillingRate extends AbstractEntity {
  date?: Date;
  product?: EntityRef;
  taxExcludedAmount?: Money;
  bill?: EntityRef;
  billingAccount?: EntityRef;
  characteristic?: Characteristic[];
  periodCoverage?: TimePeriod;
  isBilled?: boolean;
  appliedTax?: AppliedBillingTaxRate[];
  taxIncludedAmount?: Money;
  appliedBillingRateType?: string;
}
