export interface BucketRelationship extends EntityRelationship {
  bucket?: EntityRef;
}
