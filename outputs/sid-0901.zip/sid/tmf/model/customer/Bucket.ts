export interface Bucket extends AbstractEntity {
  product?: EntityRef[];
  reservedValue?: Quantity;
  bucketCounter?: BucketCounter[];
  remainingValue?: Quantity;
  bucketRelationship?: BucketRelationship[];
  creationDate?: Date;
  relatedParty?: RelatedParty[];
  logicalResource?: EntityRef[];
  bucketSpecification?: EntityRef;
  reserveBalance?: EntityRef[];
  partyAccount?: EntityRef;
  isShared?: boolean;
  remainingValueName?: string;
  usageType?: string;
  status?: string;
}
