export interface CustomerV1 extends PartyRole {
  msisdn?: string;
}
