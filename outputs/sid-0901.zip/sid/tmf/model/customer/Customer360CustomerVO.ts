export interface Customer360CustomerVO extends AbstractEntity {
  contactMedium?: ContactMedium[];
  relatedParty?: RelatedParty[];
  engagedParty?: EntityRef;
  status?: string;
}
