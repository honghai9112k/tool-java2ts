export interface Customer360PartyInteractionVO extends AbstractEntity {
  interactionDate?: TimePeriod;
  reason?: string;
  status?: string;
}
