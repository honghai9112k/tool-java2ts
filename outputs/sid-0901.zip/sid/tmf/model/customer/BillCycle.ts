export interface BillCycle extends AbstractEntity {
  billingDate?: Date;
  paymentDueDate?: Date;
  creditDate?: Date;
  billingPeriod?: string;
  mailingDate?: Date;
  chargeDate?: Date;
}
