export interface BillingCycleSpecification extends AbstractEntity {
  billingDateShift?: number;
  billingPeriod?: string;
  mailingDateOffset?: number;
  paymentDueDateOffset?: number;
  chargeDateOffset?: number;
  creditDateOffset?: number;
  frequency?: string;
}
