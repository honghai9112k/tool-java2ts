export interface Price extends AbstractEntity {
  taxRate?: number;
  taxIncludedAmount?: Money;
  dutyFreeAmount?: Money;
  percentage?: number;
}
