export interface AppliedPayment {
  code?: string;
  appliedAmount?: Money;
  payment?: EntityRef;
}
