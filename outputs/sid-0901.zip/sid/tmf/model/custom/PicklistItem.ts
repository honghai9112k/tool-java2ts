export interface PicklistItem extends AbstractEntity {
  valueType?: string;
  unitOfMeasure?: string;
  value?: any;
  isDefault?: boolean;
  valueFrom?: number;
  valueTo?: number;
}
