export interface CharacteristicValue {
  isDefault?: boolean;
  valueType?: string;
  value?: string;
  unitOfMeasure?: string;
  "@type"?: string;
}
