export interface FalloutProvisioning extends AbstractEntity {
  msisdn?: string;
  action?: string;
  rfsId?: string;
  cfsId?: string;
  productId?: string;
  poiId?: string;
  poId?: string;
  status?: string;
}
