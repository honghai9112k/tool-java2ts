export interface ConnectedInformation {
  key?: string;
  value?: string;
}
