export interface StockConvertSimToAvailable extends AbstractEntity {
  status?: string;
  type?: string;
  reason?: string;
  requestedDate?: Date;
  relatedParty?: RelatedParty[];
  stockSystem?: EntityRef;
  stockLocation?: EntityRef;
  resource?: EntityRef[];
  attachment?: AttachmentRefOrValue[];
  createdBy?: EntityRef;
  createdDate?: Date;
  lastModifiedBy?: EntityRef;
  approvedBy?: string;
}
