export interface Criteria extends AbstractEntity {
  dataType?: string;
  operator?: string[];
  layout?: Layout;
  parent?: EntityRef;
}
