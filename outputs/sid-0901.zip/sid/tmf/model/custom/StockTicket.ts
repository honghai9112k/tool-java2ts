export interface StockTicket extends AbstractEntity {
  status?: string;
  reason?: string;
  creationDate?: Date;
  requestedDate?: Date;
  requestType?: string;
  relatedParty?: RelatedParty[];
  stockLocation?: EntityRef[];
  stockSystem?: EntityRef;
  resourceSpecification?: ResourceSpecificationRef[];
  attachment?: Attachment[];
  createdBy?: EntityRef;
  createdDate?: Date;
  lastModifiedBy?: EntityRef;
  lastModified?: Date;
  stockRequest?: EntityRef;
}
