export interface StockKitConvertItem extends AbstractEntity {
  model?: string;
  category?: string;
  resourceVersion?: string;
  resourceSpecification?: EntityRef;
  resourceCharacteristic?: Characteristic[];
  stockKitConvert?: EntityRef;
}
