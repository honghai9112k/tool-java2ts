export interface BundledProposalOption extends AbstractEntity {
  numberRelOfferDefault?: number;
  numberRelOfferLowerLimit?: number;
  numberRelOfferUpperLimit?: number;
}
