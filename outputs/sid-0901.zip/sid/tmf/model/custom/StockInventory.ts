export interface StockInventory extends AbstractEntity {
  availableQuantity?: number;
  standByQuantity?: number;
  reservedQuantity?: number;
  suspendedQuantity?: number;
  pendingRemovalQuantity?: number;
  resourceSpecification?: ResourceSpecificationRef;
  stockLocation?: EntityRef;
  stockSystem?: EntityRef;
  alarmQuantity?: number;
  installedQuantity?: number;
  notExistsQuantity?: number;
  plannedQuantity?: number;
  unknownQuantity?: number;
}
