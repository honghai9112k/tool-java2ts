export interface TaskDefinitionDFormInfo {
  dueDate?: string;
  dFormDefinitionCode?: string;
  dFormDefinitionFullSpec?: string;
  dFormDefinitionName?: string;
}
