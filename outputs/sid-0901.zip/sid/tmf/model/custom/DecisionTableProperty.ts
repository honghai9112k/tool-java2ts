export interface DecisionTableProperty extends AbstractEntity {
  value?: string;
  productGroup?: EntityRef;
  propertySpecification?: DecisionTableSpecificationRef[];
}
