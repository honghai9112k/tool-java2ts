export interface WorkIssue extends AbstractEntity {
  key?: string;
  summary?: string;
  issueType?: string;
  status?: string;
  priority?: string;
  dueDate?: Date;
  startDate?: Date;
  endDate?: Date;
  note?: Note[];
  assignor?: EntityRef;
  assignee?: EntityRef;
  issues?: EntityRef[];
  workflowStep?: WorkFlowStep;
  created?: Date;
  updated?: Date;
  relatedProject?: EntityRef;
}
