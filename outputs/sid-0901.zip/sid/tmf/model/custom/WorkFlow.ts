export interface WorkFlow extends AbstractEntity {
  steps?: WorkFlowStep[];
}
