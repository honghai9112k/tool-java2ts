export interface History {
  version?: string;
  date?: string;
  status?: string;
  description?: string;
  author?: string;
}
