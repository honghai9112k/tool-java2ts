export interface ProductPropertyItem extends AbstractEntity {
  code?: string;
  description?: string;
  value?: string;
  version?: string;
  validFor?: TimePeriod;
}
