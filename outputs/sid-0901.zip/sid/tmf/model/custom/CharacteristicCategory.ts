export interface CharacteristicCategory extends AbstractEntity {
  domain?: string;
  isRoot?: boolean;
  isLeaf?: boolean;
  parent?: EntityRef;
  characteristicSpecification?: EntityRef[];
}
