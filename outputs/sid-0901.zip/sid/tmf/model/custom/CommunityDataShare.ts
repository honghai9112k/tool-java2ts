export interface CommunityDataShare extends AbstractEntity {
  serviceId?: string;
  status?: string;
  createdDate?: Date;
  modifiedDate?: Date;
  memberChangeCount?: number;
  owner?: string;
  member?: Member[];
  maxMember?: number;
}
