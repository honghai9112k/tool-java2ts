export interface OfferQueue extends AbstractEntity {
  msisdn?: string;
  packageName?: string;
  volume?: string;
  daId?: string;
  offerId?: string;
  comment?: string;
  daUnitType?: string;
  startDateTime?: Date;
  expiryDateTime?: Date;
  extraInfo?: string;
  status?: string;
  countRetry?: number;
  rfsId?: string;
  odaProductId?: string;
  callFreeDuration?: string;
}
