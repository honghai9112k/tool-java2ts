export interface DocumentInfo {
  plan?: string;
  scope?: string;
  participant?: string;
  history?: History[];
}
