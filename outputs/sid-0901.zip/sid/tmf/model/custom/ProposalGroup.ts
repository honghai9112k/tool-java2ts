export interface ProposalGroup extends AbstractEntity {
  groupType?: string;
  state?: string;
  conditionCombinationLogic?: string;
  proposalSpecification?: ProposalSpecificationRefOrValue[];
  subGroup?: ProposalGroup[];
  bundledType?: string;
}
