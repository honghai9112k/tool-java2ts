export interface SmsTemplateRelationship extends EntityRel {
  code?: string;
}
