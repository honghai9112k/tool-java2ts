export interface PolicyDomain extends AbstractEntity {
  scopedManagedEntity?: Reference[];
  subDomainRef?: Reference[];
  note?: Note[];
}
