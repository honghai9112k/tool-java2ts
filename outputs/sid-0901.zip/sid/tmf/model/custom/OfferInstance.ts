export interface OfferInstance extends AbstractEntity {
  offerId?: number;
  daId?: string;
  productId?: number;
  status?: string;
  startDate?: Date;
  expireDate?: Date;
  identifyCode?: string;
  currentCycle?: number;
  totalCycle?: number;
}
