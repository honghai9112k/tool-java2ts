export interface Matrix {
  header?: string[];
  data?: DataMatrix[];
}
