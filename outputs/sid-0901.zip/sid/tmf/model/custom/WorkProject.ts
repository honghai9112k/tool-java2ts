export interface WorkProject extends AbstractEntity {
  key?: string;
  lead?: EntityRef;
  startDate?: Date;
  status?: string;
  workflow?: EntityRef;
  issues?: EntityRef[];
}
