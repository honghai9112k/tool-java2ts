export interface RaciMatrix {
  "@type"?: string;
  name?: string;
  matrix?: Matrix;
}
