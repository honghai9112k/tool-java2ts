export interface OcsData extends AbstractEntity {
  serviceCode?: string;
  slGoi?: number;
  slThuebao?: number;
  tien?: number;
  tienBundleGoi0D?: number;
}
