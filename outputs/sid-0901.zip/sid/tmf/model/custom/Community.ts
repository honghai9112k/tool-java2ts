export interface Community extends AbstractEntity {
  communityGroupCode?: string;
  serviceId?: string;
  status?: string;
  createdDate?: Date;
  modifiedDate?: Date;
  owner?: string;
  member?: Member[];
  maxMember?: number;
}
