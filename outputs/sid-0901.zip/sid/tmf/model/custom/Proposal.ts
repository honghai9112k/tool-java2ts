export interface Proposal extends AbstractEntity {
  createdBy?: string;
  createdAt?: Date;
  externalIdentifier?: ExternalIdentifier[];
  productOffering?: EntityRef;
  workProject?: EntityRef;
  groups?: ProposalGroupBase[];
  isTemplate?: boolean;
  byTemplate?: EntityRef;
  extData?: string;
  productFamily?: string;
  isBundle?: boolean;
  bundledProposal?: BundledProposal[];
  place?: EntityRef[];
  channelAction?: AllowedProductAction[];
  productLine?: string;
  parentId?: string;
  raciMatrix?: RaciMatrix[];
  documentInfo?: DocumentInfo;
  proposalRelationship?: ProposalRelationship[];
  smsInfo?: any;
  validQuantity?: ValidQuantity[];
  cycleLength?: CycleLength;
}
