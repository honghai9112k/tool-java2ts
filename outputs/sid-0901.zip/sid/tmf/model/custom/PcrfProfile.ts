export interface PcrfProfile extends AbstractEntity {
}
