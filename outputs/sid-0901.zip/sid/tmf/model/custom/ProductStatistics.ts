export interface ProductStatistics extends AbstractEntity {
  status?: string;
  creationDate?: Date;
  fileNameRequest?: string;
  attachment?: EntityRef;
  fileResult?: EntityRef;
}
