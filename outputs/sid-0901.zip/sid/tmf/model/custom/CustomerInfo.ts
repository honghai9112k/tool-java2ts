export interface CustomerInfo extends AbstractEntity {
}
