export interface ProcessSpecification extends AbstractEntity {
  domain?: string;
  processType?: string;
  businessProcess?: string;
  businessProcessInfo?: BusinessProcessInfo;
  businessDetailUrl?: string;
  channel?: EntityRef[];
  relatedParty?: RelatedParty[];
  taskFlowSpecification?: EntityRef[];
  functionCode?: string;
  tenantId?: string;
}
