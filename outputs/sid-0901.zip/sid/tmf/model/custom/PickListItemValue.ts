export interface PickListItemValue extends AbstractEntity {
  code?: string;
  label?: string;
  url?: string;
}
