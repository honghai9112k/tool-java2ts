export interface ResourceSpecificationRef extends EntityRef {
  quantity?: number;
  quantityProcessed?: number;
  resourceType?: string;
  model?: string;
  productId?: string;
  productName?: string;
  stockItemId?: string;
  location?: EntityRef;
  resourceCategory?: EntityRef;
  characteristics?: CharacteristicSpecification[];
  version?: string;
  resourceSpecRelationship?: ResourceSpecificationRelationship[];
}
