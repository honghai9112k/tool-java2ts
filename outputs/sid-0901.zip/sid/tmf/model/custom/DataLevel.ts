export interface DataLevel extends AbstractEntity {
  dataLevel?: number;
  status?: string;
}
