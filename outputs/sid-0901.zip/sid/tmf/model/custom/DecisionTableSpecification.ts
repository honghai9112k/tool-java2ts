export interface DecisionTableSpecification extends AbstractEntity {
  value?: string;
}
