export interface StockTicketRelationship extends AbstractEntity {
}
