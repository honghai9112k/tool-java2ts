export interface OrderResponse {
  status?: string;
  statusMessage?: string;
  timeResponse?: string;
  orderId?: string;
}
