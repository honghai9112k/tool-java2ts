export interface OrderImportDetail extends AbstractEntity {
  status?: string;
  creationDate?: Date;
  fileNameRequest?: string;
  orderRequests?: OrderRequest[];
  attachment?: EntityRef;
  fileResult?: EntityRef;
}
