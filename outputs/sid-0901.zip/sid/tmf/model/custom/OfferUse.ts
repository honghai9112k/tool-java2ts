export interface OfferUse extends AbstractEntity {
  msisdn?: string;
  serviceId?: string;
  rfsCode?: string;
  offerId?: string;
  daId?: string;
  productId?: string;
  status?: string;
}
