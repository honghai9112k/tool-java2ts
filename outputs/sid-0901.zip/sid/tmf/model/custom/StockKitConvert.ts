export interface StockKitConvert extends AbstractEntity {
  status?: string;
  reason?: string;
  requestedDate?: Date;
  approvedBy?: string;
  relatedParty?: RelatedParty[];
  connectedinformation?: ConnectedInformation[];
  stockSystem?: EntityRef;
  stockLocation?: EntityRef;
  attachment?: Attachment[];
  createdBy?: EntityRef;
  createdDate?: Date;
}
