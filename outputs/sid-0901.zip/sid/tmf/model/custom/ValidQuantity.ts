export interface ValidQuantity {
  "@type"?: string;
  validFor?: TimePeriod;
  quantity?: string;
}
