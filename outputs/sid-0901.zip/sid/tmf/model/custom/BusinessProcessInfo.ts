export interface BusinessProcessInfo {
  id?: string;
  name?: string;
  key?: string;
  fileId?: string;
  deployed?: boolean;
}
