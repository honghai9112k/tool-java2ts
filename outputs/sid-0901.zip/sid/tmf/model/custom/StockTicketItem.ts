export interface StockTicketItem extends AbstractEntity {
  resourceSpecification?: EntityRef;
  resourceSerialNumber?: string;
  resourceStatus?: string;
  resourceCharacteristic?: Characteristic[];
  stockTicket?: EntityRef;
}
