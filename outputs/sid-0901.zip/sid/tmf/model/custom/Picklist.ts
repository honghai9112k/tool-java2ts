export interface Picklist extends AbstractEntity {
  dataType?: string;
  active?: boolean;
  assetuserroleid?: string;
  items?: PicklistItem[];
}
