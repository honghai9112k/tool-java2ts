export interface StockCheckTicketItem extends AbstractEntity {
  status?: string;
  completedTime?: Date;
  resourceStatusBefore?: string;
  resourceStatusAfter?: string;
  stockCheckTicket?: EntityRef;
  stockLocation?: EntityRef;
  resource?: ResourceRef;
}
