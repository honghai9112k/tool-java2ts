export interface StockSystem extends AbstractEntity {
  status?: string;
  relatedParty?: RelatedParty[];
  features?: Feature[];
  createdBy?: EntityRef;
  createdDate?: Date;
  lastModifiedBy?: EntityRef;
  lastModifiedDate?: Date;
  resourceCatalogId?: string;
}
