export interface CommandImportDetail extends AbstractEntity {
  status?: string;
  templateName?: string;
  creationDate?: Date;
  attachment?: EntityRef;
  systemUsed?: string;
  fileResult?: EntityRef;
  fileNameRequest?: string;
}
