export interface Member {
  msisdn?: string;
  status?: string;
  createdDate?: Date;
  modifiedDate?: Date;
}
