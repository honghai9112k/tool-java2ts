export interface DecisionTableGroup extends AbstractEntity {
}
