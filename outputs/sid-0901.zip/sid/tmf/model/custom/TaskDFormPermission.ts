export interface TaskDFormPermission {
  owner?: string;
}
