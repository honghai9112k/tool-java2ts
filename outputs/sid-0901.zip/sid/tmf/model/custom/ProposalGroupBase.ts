export interface ProposalGroupBase extends AbstractEntity {
  groupType?: string;
  state?: string;
  conditionCombinationLogic?: string;
  proposalSpecification?: ProposalSpecification[];
  subGroup?: ProposalGroupBase[];
  qualificationType?: string;
  bundledType?: string;
}
