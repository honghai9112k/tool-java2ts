export interface OrderMapRequest extends AbstractEntity {
  service_oda?: string;
  system_target?: string;
  service_data_sps?: string;
  channel?: string;
}
