export interface VanityLines extends AbstractEntity {
  priorityLevel?: number;
  prefix?: string;
  regexPattern?: string;
  status?: string;
  description?: string;
  version?: string;
  validFor?: TimePeriod;
}
