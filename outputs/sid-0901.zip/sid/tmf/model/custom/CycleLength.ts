export interface CycleLength {
  value?: number;
  unitOfMeasure?: string;
}
