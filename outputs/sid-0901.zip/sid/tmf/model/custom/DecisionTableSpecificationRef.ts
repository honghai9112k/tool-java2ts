export interface DecisionTableSpecificationRef extends EntityRef {
  code?: string;
  value?: string;
  version?: string;
  validFor?: TimePeriod;
}
