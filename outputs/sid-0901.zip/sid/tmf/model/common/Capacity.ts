export interface Capacity extends AbstractEntity {
  place?: PlaceRefOrValue;
  capacitySpecification?: EntityRef;
  rangeInterval?: string;
  capacityStatus?: string;
  applicableTimePeriod?: ApplicableTimePeriod[];
  relatedCapacity?: Capacity[];
  capacityCharacteristic?: Characteristic[];
  plannedOrActualCapacity?: string;
  capacitySpec?: EntityRef;
  capacityAmountTo?: Quantity;
  capacityAmount?: Quantity;
  capacityAmountFrom?: Quantity;
}
