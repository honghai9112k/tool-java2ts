export interface TokenCredential extends Credential {
}
