export interface Any extends AbstractEntity {
}
