export interface FeatureSpecification extends AbstractEntity {
  isBundle?: boolean;
  featureSpecRelationship?: FeatureSpecificationRelationship[];
  isEnabled?: boolean;
  policyConstraint?: EntityRef[];
  featureSpecCharacteristic?: CharacteristicSpecification[];
}
