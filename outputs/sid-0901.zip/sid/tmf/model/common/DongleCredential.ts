export interface DongleCredential extends Credential {
}
