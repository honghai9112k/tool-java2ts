export interface RelatedChannel extends AbstractEntity {
  channel?: EntityRef;
  role?: string;
}
