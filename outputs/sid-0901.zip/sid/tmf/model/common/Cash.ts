export interface Cash extends PaymentMethod {
}
