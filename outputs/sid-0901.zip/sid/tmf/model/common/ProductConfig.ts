export interface ProductConfig extends AbstractEntity {
  productCode?: string;
  value?: string;
}
