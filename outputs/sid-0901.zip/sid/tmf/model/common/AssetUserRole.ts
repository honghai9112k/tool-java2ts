export interface AssetUserRole {
  manageableAsset?: EntityRef;
  userRole?: EntityRef;
  "@baseType"?: string;
  "@schemaLocation"?: string;
  "@type"?: string;
}
