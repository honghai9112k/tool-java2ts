export interface TroubleTicketSpecification_RES extends TroubleTicketSpecification {
}
