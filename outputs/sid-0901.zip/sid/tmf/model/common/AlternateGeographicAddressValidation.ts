export interface AlternateGeographicAddressValidation extends GeographicAddress {
  matchingDegree?: string;
  matchinRule?: string;
  similarityScore?: number;
}
