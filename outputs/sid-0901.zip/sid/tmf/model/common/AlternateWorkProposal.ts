export interface AlternateWorkProposal extends AbstractEntity {
  alternateWorkDate?: Date;
  alternateWork?: WorkRefOrValue;
}
