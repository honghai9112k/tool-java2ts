export interface IntentRefOrValue extends EntityRefOrValue {
}
