export interface PlaceRefOrValue extends EntityRefOrValue {
}
