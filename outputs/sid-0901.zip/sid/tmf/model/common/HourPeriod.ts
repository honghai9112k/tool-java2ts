export interface HourPeriod extends AbstractEntity {
  endHour?: string;
  startHour?: string;
}
