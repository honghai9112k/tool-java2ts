export interface Privilege {
  action?: string;
  function?: string;
  manageableAsset?: EntityRef;
  "@baseType"?: string;
  "@schemaLocation"?: string;
  "@type"?: string;
}
