export interface WorkQualificationItemRelationship extends EntityRel {
  code?: string;
}
