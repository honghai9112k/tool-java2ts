export interface GeographicAddressValue extends AbstractEntity {
  country?: string;
  streetType?: string;
  city?: string;
  streetNr?: string;
  locality?: string;
  postcode?: string;
  streetNrLast?: string;
  streetNrSuffix?: string;
  streetName?: string;
  stateOrProvince?: string;
  streetNrLastSuffix?: string;
  streetSuffix?: string;
  geographicSubAddress?: GeographicSubAddressValue;
}
