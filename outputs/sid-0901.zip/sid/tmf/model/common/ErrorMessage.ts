export interface ErrorMessage extends AbstractEntity {
  reason?: string;
  message?: string;
  status?: string;
  referenceError?: string;
}
