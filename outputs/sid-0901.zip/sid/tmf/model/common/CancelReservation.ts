export interface CancelReservation extends AbstractEntity {
  cancellationReason?: string;
  effectiveCancellationDate?: string;
  requestedCancellationDate?: string;
  state?: string;
}
