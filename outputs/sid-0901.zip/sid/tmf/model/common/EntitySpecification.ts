export interface EntitySpecification extends AbstractCatalogEntity {
  isBundle?: boolean;
  targetEntitySchema?: TargetEntitySchema;
  specCharacteristic?: CharacteristicSpecification[];
  entitySpecRelationship?: EntitySpecificationRelationship[];
  relatedParty?: RelatedParty[];
  attachment?: RelatedPlaceRefOrValue[];
  constraint?: EntityRef[];
}
