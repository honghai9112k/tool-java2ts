export interface Characteristic extends AbstractEntity {
  characteristicRelationship?: CharacteristicRelationship[];
  valueType?: string;
  value?: any;
  unitOfMeasure?: string;
  minCardinality?: number;
  regex?: string;
  isConfigurable?: boolean;
  maxCardinality?: number;
  required?: boolean;
}
