export interface TargetEntitySchema extends AbstractEntity {
}
