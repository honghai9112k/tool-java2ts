export interface CharacteristicValueSpecification extends AbstractEntity {
  rangeInterval?: string;
  isDefault?: boolean;
  valueTo?: number;
  regex?: string;
  value?: any;
  unitOfMeasure?: string;
  valueType?: string;
  valueFrom?: number;
}
