export interface SmsSubcriberType extends AbstractEntity {
  subType?: string;
  cycleLengthUOM?: string;
  key?: string[];
  value?: string[];
}
