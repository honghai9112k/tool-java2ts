export interface CharacteristicSpecificationRelationship extends EntityRel {
  code?: string;
  characteristicSpecificationId?: string;
  parentSpecificationHref?: string;
  parentSpecificationId?: string;
}
