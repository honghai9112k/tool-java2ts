export interface IntentReport extends AbstractEntity {
  expression?: IntentExpression;
  creationDate?: Date;
  intent?: IntentRefOrValue;
}
