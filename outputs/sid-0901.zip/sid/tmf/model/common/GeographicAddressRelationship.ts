export interface GeographicAddressRelationship extends EntityRel {
  code?: string;
}
