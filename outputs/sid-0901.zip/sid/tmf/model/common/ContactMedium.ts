export interface ContactMedium extends AbstractEntity {
  contactType?: string;
  preferred?: boolean;
  mediumType?: string;
  phoneNumber?: string;
  emailAddress?: string;
  faxNumber?: string;
  socialNetworkId?: string;
  geographicAddress?: EntityRef;
  characteristic?: MediumCharacteristic;
}
