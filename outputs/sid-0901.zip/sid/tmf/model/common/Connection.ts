export interface Connection extends AbstractEntity {
  associationType?: string;
  endpoint?: EndpointRef;
}
