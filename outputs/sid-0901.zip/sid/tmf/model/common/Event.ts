export interface Event extends AbstractEntity {
  eventId?: string;
  analyticCharacteristic?: Characteristic[];
  source?: EntityRef;
  eventType?: string;
  title?: string;
  priority?: string;
  relatedParty?: EntityRef[];
  domain?: string;
  eventTime?: Date;
  reportingSystem?: EntityRef;
  correlationId?: string;
  event?: string;
  timeOccurred?: Date;
}
