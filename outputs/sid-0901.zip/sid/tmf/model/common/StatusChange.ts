export interface StatusChange extends AbstractEntity {
  statusChangeDate?: Date;
  statusChangeReason?: string;
  status?: string;
}
