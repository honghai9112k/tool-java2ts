export interface ProbeIntent extends Intent {
}
