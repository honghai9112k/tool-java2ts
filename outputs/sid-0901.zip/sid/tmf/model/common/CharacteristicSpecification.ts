export interface CharacteristicSpecification extends AbstractEntity {
  "@valueSchemaLocation"?: string;
  isUnique?: boolean;
  maxCardinality?: number;
  minCardinality?: number;
  regex?: string;
  valueType?: string;
  charSpecRelationship?: CharacteristicSpecificationRelationship[];
  characteristicValueSpecification?: CharacteristicValueSpecification[];
  extensible?: boolean;
  configurable?: boolean;
  value?: any;
  unitOfMeasure?: string;
  pickList?: string;
  layout?: Layout;
  characteristicCatalog?: EntityRef;
  isTemplate?: boolean;
  productSpecification?: EntityRef;
  characteristicValueSpecificationUsed?: CharacteristicValueSpecification;
}
