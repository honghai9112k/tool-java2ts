export interface UserRole {
  id?: string;
  href?: string;
  involvementRole?: string;
  entitlement?: Entitlement[];
  "@baseType"?: string;
  "@schemaLocation"?: string;
  "@type"?: string;
}
