export interface InteractionItemRelationship extends EntityRel {
  code?: string;
}
