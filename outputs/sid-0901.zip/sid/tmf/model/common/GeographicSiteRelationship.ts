export interface GeographicSiteRelationship extends EntityRel {
  code?: string;
}
