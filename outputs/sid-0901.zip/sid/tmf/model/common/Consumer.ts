export interface Consumer extends PartyRole {
}
