export interface TokenizedCard extends PaymentMethod {
}
