export interface ProcessFlow extends AbstractEntity {
  processFlowSpecification?: string;
  taskFlow?: EntityRef[];
  relatedEntity?: RelatedEntity[];
  channel?: EntityRef[];
  processFlowSpecificationRef?: EntityRef;
  state?: string;
  relatedParty?: RelatedParty[];
  characteristic?: Characteristic[];
  processFlowDate?: Date;
}
