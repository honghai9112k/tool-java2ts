export interface CharacteristicSpecificationBase extends AbstractEntity {
  configurable?: boolean;
  extensible?: boolean;
  isUnique?: boolean;
  maxCardinality?: number;
  minCardinality?: number;
  regex?: string;
  valueType?: string;
  "@valueSchemaLocation"?: string;
}
