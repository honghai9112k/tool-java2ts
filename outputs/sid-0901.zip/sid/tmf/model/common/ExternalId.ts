export interface ExternalId extends AbstractEntity {
  entityType?: string;
  owner?: string;
}
