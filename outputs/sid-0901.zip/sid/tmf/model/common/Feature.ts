export interface Feature extends AbstractEntity {
  isBundle?: boolean;
  isEnabled?: boolean;
  featureCharacteristic?: Characteristic[];
  constraint?: EntityRef[];
  featureRelationship?: FeatureRelationship[];
  featureCharacteritic?: Characteristic[];
  type?: string;
  children?: Feature[];
}
