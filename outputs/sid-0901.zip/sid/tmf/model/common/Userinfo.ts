export interface Userinfo extends AbstractEntity {
  sub?: string;
  family_name?: string;
  given_name?: string;
  middle_name?: string;
  nickname?: string;
  preferred_username?: string;
  address?: GeographicAddress;
  birthdate?: string;
  email?: string;
  email_verified?: boolean;
  gender?: string;
  legalId?: IndividualIdentification[];
  locale?: string;
  phone_number?: string;
  phone_number_verified?: boolean;
  picture?: string;
  profile?: string;
  website?: string;
  zoneinfo?: string;
  userPermission?: EntityRef[];
}
