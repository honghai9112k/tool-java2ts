export interface WorkPrice extends AbstractEntity {
  recurringChargePeriod?: string;
  unitOfMeasure?: string;
  billingAccount?: EntityRef;
  price?: Price;
  priceAlteration?: PriceAlteration[];
  priceType?: string;
  productOfferingPrice?: EntityRef;
}
