export interface RatedCdr {
  isBilled?: boolean;
  offerTariffType?: string;
  ratingAmountType?: string;
  ratingDate?: Date;
  isTaxExempt?: boolean;
  productRef?: EntityRef;
  taxExcludedRatingAmount?: Money;
  taxIncludedRatingAmount?: Money;
  taxRate?: number;
}
