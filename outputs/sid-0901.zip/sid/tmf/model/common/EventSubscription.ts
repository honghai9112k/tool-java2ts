export interface EventSubscription extends AbstractEntity {
  callback?: string;
  query?: string;
}
