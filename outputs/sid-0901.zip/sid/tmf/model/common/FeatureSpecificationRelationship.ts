export interface FeatureSpecificationRelationship extends EntityRel {
  code?: string;
  parentSpecificationHref?: string;
  featureId?: string;
  parentSpecificationId?: string;
}
