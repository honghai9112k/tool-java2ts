export interface TroubleTicket extends AbstractEntity {
  severity?: string;
  statusChangeReason?: string;
  note?: Note[];
  troubleTicketRelationship?: TroubleTicketRelationship[];
  troubleTicketSpecification?: EntityRef;
  resolutionDate?: Date;
  relatedEntity?: RelatedEntity[];
  channel?: EntityRef;
  ticketType?: string;
  creationDate?: Date;
  priority?: string;
  relatedParty?: RelatedParty[];
  statusChangeDate?: Date;
  attachment?: AttachmentRefOrValue[];
  statusChangeHistory?: StatusChange[];
  expectedResolutionDate?: Date;
  troubleTicketCharacteristic?: Characteristic[];
  externalIdentifier?: ExternalIdentifier[];
  requestedResolutionDate?: Date;
  status?: string;
}
