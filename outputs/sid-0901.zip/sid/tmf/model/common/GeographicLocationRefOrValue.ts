export interface GeographicLocationRefOrValue extends EntityRefOrValue {
}
