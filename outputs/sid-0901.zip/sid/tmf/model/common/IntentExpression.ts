export interface IntentExpression extends AbstractEntity {
  iri?: string;
  expressionValue?: any;
}
