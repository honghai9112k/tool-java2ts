export interface EventSubscriptionInput {
  code?: string;
  callback?: string;
  query?: string;
}
