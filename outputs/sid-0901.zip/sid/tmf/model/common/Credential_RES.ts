export interface Credential_RES extends Credential {
}
