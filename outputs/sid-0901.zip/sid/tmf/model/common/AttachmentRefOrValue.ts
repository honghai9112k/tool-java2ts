export interface AttachmentRefOrValue extends EntityRefOrValue {
}
