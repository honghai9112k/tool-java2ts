export interface EntitySpecificationRelationship extends EntityRel {
  code?: string;
  associationSpec?: EntityRef;
}
