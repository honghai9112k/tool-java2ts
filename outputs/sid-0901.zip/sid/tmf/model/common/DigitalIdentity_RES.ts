export interface DigitalIdentity_RES extends DigitalIdentity {
}
