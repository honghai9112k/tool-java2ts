export interface Voucher extends PaymentMethod {
}
