export interface LinearRing {
  code?: string;
  positions?: Position[];
}
