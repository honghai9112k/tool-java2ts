export interface JSONPathAssetGroup extends AssetGroup {
}
