export interface Check extends PaymentMethod {
}
