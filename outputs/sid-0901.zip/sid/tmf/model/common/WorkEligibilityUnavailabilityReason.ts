export interface WorkEligibilityUnavailabilityReason extends AbstractEntity {
  label?: string;
}
