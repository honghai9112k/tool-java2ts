export interface WorkSpecificationRelationship extends EntityRel {
  code?: string;
  associationSpec?: EntityRef;
}
