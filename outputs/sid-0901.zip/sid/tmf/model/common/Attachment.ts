export interface Attachment extends AbstractEntity {
  url?: string;
  content?: string;
  size?: Quantity;
  attachmentType?: string;
  mimeType?: string;
  filePath?: string;
  statusDeploy?: boolean;
  value?: string;
}
