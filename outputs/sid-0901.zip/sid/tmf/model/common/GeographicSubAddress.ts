export interface GeographicSubAddress extends AbstractEntity {
  buildingName?: string;
  subUnit?: GeographicSubAddressUnit[];
  levelType?: string;
  levelNumber?: string;
  subAddressType?: string;
  privateStreetNumber?: string;
  privateStreetName?: string;
}
