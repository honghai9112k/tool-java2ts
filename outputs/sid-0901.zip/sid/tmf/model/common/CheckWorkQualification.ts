export interface CheckWorkQualification extends AbstractEntity {
  checkWorkQualificationDate?: Date;
  effectiveQualificationDate?: Date;
  estimatedResponseDate?: Date;
  expectedQualificationDate?: Date;
  expirationDate?: Date;
  externalId?: string;
  instantSyncQualification?: boolean;
  provideAlternative?: boolean;
  provideUnavailabilityReason?: boolean;
  qualificationResult?: string;
  place?: EntityRef;
  relatedParty?: RelatedParty[];
  workQualificationItem?: CheckWorkQualificationItem[];
}
