export interface WorkRefOrValue extends EntityRefOrValue {
}
