export interface TaxDefinition extends AbstractEntity {
  jurisdictionLevel?: string;
  taxType?: string;
  jurisdictionName?: string;
}
