export interface EntityCatalogItem extends AbstractEntity {
  category?: EntityRef[];
  specification?: EntityRef;
}
