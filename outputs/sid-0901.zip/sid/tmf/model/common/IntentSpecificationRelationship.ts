export interface IntentSpecificationRelationship extends EntityRel {
}
