export interface SmsConfigDetail extends AbstractEntity {
  productCode?: string;
  quantity?: number;
  key?: string[];
  value?: string[];
}
