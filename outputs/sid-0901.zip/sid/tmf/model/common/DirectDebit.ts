export interface DirectDebit extends PaymentMethod {
}
