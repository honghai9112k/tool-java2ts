export interface FeatureRelationship extends EntityRel {
  code?: string;
}
