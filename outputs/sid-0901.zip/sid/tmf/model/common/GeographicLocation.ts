export interface GeographicLocation extends Place {
  bbox?: number[];
  geoJson?: any;
  place?: RelatedPlaceRefOrValue[];
}
