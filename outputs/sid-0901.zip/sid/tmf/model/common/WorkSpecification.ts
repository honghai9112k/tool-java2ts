export interface WorkSpecification extends EntitySpecification {
}
