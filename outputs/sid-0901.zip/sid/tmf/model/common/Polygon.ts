export interface Polygon {
  code?: string;
  coordinates?: LinearRing[];
}
