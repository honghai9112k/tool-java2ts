export interface RelatedPlaceRefOrValue extends EntityRefOrValue {
  role?: string;
  place?: PlaceRefOrValue;
}
