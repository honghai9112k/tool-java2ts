export interface ExpressionSpecification extends AbstractEntity {
  expressionLanguage?: string;
  iri?: string;
}
