export interface EntityODACatalogItem extends EntityCatalogItem {
  characteristic?: Characteristic[];
}
