export interface Addressable extends AbstractEntity {
}
