export interface AvailabilityCheck extends TaskResource {
  capacityDemand?: Capacity;
  capacityOption?: Capacity[];
}
