export interface ConnectionPointRef extends AbstractEntity {
}
