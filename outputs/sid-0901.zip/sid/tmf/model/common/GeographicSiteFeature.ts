export interface GeographicSiteFeature extends Feature {
  note?: Note[];
  attachment?: RelatedPlaceRefOrValue[];
  relatedParty?: RelatedParty[];
  featureCategory?: string[];
  validFor?: CalendarPeriod[];
}
