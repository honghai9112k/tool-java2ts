export interface GeographicAddressStreet extends AbstractEntity {
  cityCode?: string;
  localityCode?: string;
  streetName?: string;
}
