export interface Position {
  code?: string;
  items?: number[];
}
