export interface Point {
  code?: string;
  type?: string;
  coordinates?: Position;
}
