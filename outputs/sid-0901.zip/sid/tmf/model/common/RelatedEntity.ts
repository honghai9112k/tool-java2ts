export interface RelatedEntity extends AbstractEntity {
  role?: string;
}
