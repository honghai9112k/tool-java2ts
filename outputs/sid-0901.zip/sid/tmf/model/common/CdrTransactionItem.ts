export interface CdrTransactionItem extends AbstractEntity {
  cdr?: Cdr[];
  action?: string;
  bill?: EntityRef[];
  payment?: EntityRef[];
  state?: string;
  relatedParty?: RelatedParty;
}
