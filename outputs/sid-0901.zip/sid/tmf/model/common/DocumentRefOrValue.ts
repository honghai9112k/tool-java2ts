export interface DocumentRefOrValue extends EntityRefOrValue {
}
