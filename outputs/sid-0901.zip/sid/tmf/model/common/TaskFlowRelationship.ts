export interface TaskFlowRelationship {
  code?: string;
  relationshipType?: string;
  taskFlow?: EntityRef;
}
