export interface ListAssetGroup extends AssetGroup {
}
