export interface IntentReportAttributeValueChange extends Event {
  eventPayload?: IntentReportAttributeValueChangePayload;
}
