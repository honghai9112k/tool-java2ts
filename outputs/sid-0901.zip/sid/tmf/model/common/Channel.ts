export interface Channel extends AbstractEntity {
}
