export interface TaskFlow extends AbstractEntity {
  taskFlowSpecificationRef?: EntityRef;
  relatedEntity?: RelatedEntity[];
  channel?: EntityRef[];
  taskFlowRelationship?: TaskFlowRelationship[];
  priority?: number;
  relatedParty?: RelatedParty[];
  characteristic?: Characteristic[];
  requestedStartDate?: Date;
  completionMethod?: string;
  taskFlowSpecification?: string;
  completionDate?: Date;
  isMandatory?: boolean;
  startDate?: Date;
  requestedCompletionDate?: Date;
}
