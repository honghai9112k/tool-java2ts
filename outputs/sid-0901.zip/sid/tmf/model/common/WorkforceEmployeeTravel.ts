export interface WorkforceEmployeeTravel extends AbstractEntity {
  state?: string;
  place?: EntityRef;
  timeSlot?: TimeSlot[];
}
