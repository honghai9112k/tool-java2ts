export interface Monitor extends AbstractEntity {
  sourceHref?: string;
  state?: string;
  request?: Request;
  response?: Response;
}
