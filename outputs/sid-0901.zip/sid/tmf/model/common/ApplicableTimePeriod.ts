export interface ApplicableTimePeriod extends AbstractEntity {
  dayOfWeek?: string;
  rangeInterval?: string;
  fromToDateTime?: TimePeriod;
}
