export interface Migrate extends AbstractEntity {
  adminStateModification?: string;
  cause?: string;
  completionMode?: string;
  priority?: number;
  startTime?: string;
  addConnectionPoint?: EntityRef[];
  characteristics?: Characteristic[];
  place?: EntityRef;
  removeConnectionPoint?: EntityRef[];
  resourceFunction?: ResourceFunction;
  state?: string;
}
