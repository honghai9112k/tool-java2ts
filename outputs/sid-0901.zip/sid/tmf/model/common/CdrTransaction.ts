export interface CdrTransaction extends AbstractEntity {
  note?: Note[];
  transactionItem?: CdrTransactionItem[];
  requestedInitialState?: string;
  cancellationReason?: string;
  channel?: RelatedChannel[];
  completionDate?: Date;
  state?: string;
  relatedParty?: RelatedParty[];
  creationDate?: Date;
  cancellationDate?: Date;
}
