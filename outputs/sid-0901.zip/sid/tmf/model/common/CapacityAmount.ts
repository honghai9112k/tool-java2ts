export interface CapacityAmount extends AbstractEntity {
  capacityAmount?: string;
  capacityAmountFrom?: string;
  capacityAmountTo?: string;
  rangeInterval?: string;
}
