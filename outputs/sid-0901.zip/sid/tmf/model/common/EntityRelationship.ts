export interface EntityRelationship extends EntityRel {
  code?: string;
  associationSpec?: EntityRef;
}
