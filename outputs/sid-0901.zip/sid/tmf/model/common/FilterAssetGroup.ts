export interface FilterAssetGroup extends AssetGroup {
}
