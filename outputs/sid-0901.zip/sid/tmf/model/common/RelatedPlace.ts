export interface RelatedPlace extends AbstractEntity {
  role?: string;
}
