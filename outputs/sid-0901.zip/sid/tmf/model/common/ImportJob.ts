export interface ImportJob extends AbstractEntity {
  completionDate?: Date;
  contentType?: string;
  creationDate?: Date;
  errorLog?: string;
  path?: string;
  status?: string;
  url?: string;
}
