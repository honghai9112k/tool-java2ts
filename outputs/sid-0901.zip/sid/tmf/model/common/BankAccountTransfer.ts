export interface BankAccountTransfer extends PaymentMethod {
}
