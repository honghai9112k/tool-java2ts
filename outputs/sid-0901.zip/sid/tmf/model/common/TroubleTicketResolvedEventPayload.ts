export interface TroubleTicketResolvedEventPayload {
  troubleTicket?: TroubleTicket;
}
