export interface BaseEntity extends AbstractEntity {
}
