export interface Money {
  unit?: string;
  value?: number;
  blockSize?: number;
  overagePrice?: number;
}
