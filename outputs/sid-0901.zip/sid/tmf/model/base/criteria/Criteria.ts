export interface Criteria extends BranchNode {
}
