export interface Operation {
  operator?: Operator;
  values?: HashSet<OperationValue>;
}
