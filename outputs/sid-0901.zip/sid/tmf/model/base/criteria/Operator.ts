export enum Operator {
  EQUAL = "eq",
  GREATER_THAN = "gt",
  GREATER_THAN_EQUAL = "gte",
  LESS_THAN = "lt",
  LESS_THAN_EQUAL = "lte",
  NOT_EQUAL = "ne",
  REG_EXP = "ex"
}
