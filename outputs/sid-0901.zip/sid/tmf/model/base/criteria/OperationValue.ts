export interface OperationValue {
  inputValue?: string;
  objectValue?: Comparable;
}
