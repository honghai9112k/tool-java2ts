export interface NodeNames {
  externalName?: final String;
  internalName?: string;
}
