export interface AbstractNode {
  names?: final NodeNames;
}
