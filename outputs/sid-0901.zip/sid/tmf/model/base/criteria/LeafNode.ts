export interface LeafNode extends AbstractNode {
  operations?: EnumMap<Operator, Operation>;
}
