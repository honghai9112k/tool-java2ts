export interface BranchNode extends AbstractNode {
  children?: { [key: string]: AbstractNode };
}
