export interface EntityOrOtherEntity extends AbstractEntity {
}
