export interface ServiceLevelAgreement {
  id?: string;
  href?: string;
  name?: string;
}
