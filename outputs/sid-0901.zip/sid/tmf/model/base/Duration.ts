export interface Duration {
  amount?: number;
  units?: string;
}
