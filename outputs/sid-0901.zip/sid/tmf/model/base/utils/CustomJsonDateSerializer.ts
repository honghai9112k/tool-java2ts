export interface CustomJsonDateSerializer extends JsonSerializer {
}
