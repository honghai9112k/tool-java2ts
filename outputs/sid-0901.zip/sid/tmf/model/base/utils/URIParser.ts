export interface URIParser {
}
