export interface AbstractEntityRef {
}
