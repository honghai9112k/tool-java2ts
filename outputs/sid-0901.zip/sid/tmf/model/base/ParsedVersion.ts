export interface ParsedVersion {
  majorVersion?: number;
  minorVersion?: number;
  externalView?: string;
  internalView?: string;
  valid?: boolean;
}
