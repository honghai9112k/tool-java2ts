export interface BaseDocument extends AbstractEntity {
  documentSpecification?: DocumentSpecification;
  documentType?: string;
  relatedEntity?: RelatedEntity;
  creationDate?: Date;
  relatedParty?: RelatedParty[];
  characteristic?: Characteristic[];
  attachment?: AttachmentRefOrValue[];
  category?: EntityRef[];
  documentRelationship?: EntityRef[];
}
