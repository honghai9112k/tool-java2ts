export interface ClassFields {
  fields?: final HashMap<String, Field>;
  jsonNames?: final HashMap<String, String>;
}
