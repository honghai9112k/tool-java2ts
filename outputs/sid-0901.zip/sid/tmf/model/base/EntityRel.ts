export interface EntityRel extends AbstractEntityRef {
  id?: string;
  href?: string;
  name?: string;
  relationshipType?: string;
  role?: string;
  validFor?: TimePeriod;
  "@type"?: string;
  "@baseType"?: string;
  "@schemaLocation"?: string;
  "@referredType"?: string;
}
