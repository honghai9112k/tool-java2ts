export interface Response {
  code?: string;
  body?: any;
  statusCode?: number;
  xTotalCount?: number;
  xTotalResultCount?: number;
}
