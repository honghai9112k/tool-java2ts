export interface Attachment {
  id?: string;
  href?: string;
  description?: string;
  type?: string;
  url?: string;
}
