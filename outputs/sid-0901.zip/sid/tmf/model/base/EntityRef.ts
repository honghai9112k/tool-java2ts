export interface EntityRef extends AbstractEntityRef {
  id?: string;
  href?: string;
  name?: string;
  code?: string;
  description?: string;
  "@type"?: string;
  "@baseType"?: string;
  "@schemaLocation"?: string;
  "@referredType"?: string;
  entity?: AbstractEntity;
}
