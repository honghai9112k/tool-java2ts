export interface Note {
  id?: string;
  author?: string;
  date?: Date;
  text?: string;
  "@baseType"?: string;
  "@schemaLocation"?: string;
  "@type"?: string;
}
