export interface QueryParameterParser {
  tagsWithNoValue?: final HashSet<String>;
  tagsWithValue?: final MultivaluedHashMap<String, String>;
}
