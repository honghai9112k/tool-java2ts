export interface ReferencedEntityGetter {
  theClass?: final Class;
  referenceFields?: final HashMap<String, Class>;
}
