export interface EntityRefOrValue extends EntityRef {
}
