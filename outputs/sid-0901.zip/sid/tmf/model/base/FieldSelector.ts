export interface FieldSelector extends HashMap {
  theClass?: final Class;
  classFieldsCache?: final ClassFieldsCache;
  setMethodsCache?: final HashMap<Class, SetMethods>;
  propertyUtilsBean?: static PropertyUtilsBean;
  simplePaths?: HashSet<string>;
  complexPaths?: { [key: string]: HashSet<string> };
}
