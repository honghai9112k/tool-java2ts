export interface AnyValue {
}
