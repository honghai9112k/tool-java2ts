export interface Extensible {
  "@type"?: string;
  "@baseType"?: string;
  "@schemaLocation"?: string;
}
