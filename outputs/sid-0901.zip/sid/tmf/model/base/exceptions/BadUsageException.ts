export interface BadUsageException extends FunctionalException {
}
