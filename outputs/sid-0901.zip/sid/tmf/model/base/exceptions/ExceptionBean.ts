export interface ExceptionBean {
  code?: string;
  title?: string;
}
