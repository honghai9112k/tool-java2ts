export interface InvalidEnumeratedValueException extends FunctionalException {
}
