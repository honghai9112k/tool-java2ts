export interface UnknownResourceException extends FunctionalException {
}
