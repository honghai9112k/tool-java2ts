export enum ExceptionType {
  // No enum values found
}
