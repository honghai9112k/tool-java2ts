// Skipped: Not suitable for interface conversion
