export interface Quantity {
  amount?: number;
  units?: string;
}
