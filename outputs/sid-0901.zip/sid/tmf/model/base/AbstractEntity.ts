export interface AbstractEntity {
  id?: string;
  href?: string;
  name?: string;
  code?: string;
  description?: string;
  version?: string;
  lifecycleStatus?: string;
  validFor?: TimePeriod;
  lastUpdate?: Date;
  "@type"?: string;
  "@baseType"?: string;
  "@schemaLocation"?: string;
  "@referredType"?: string;
  userId?: string;
  orgId?: string;
  dataOwnerId?: string;
}
