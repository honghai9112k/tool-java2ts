export interface ClassFieldsCache {
  cache?: final HashMap<Class, ClassFields>;
}
