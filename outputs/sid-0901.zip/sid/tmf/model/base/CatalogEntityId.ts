export interface CatalogEntityId {
  catalogId?: string;
  catalogVersion?: string;
  id?: string;
  version?: string;
}
