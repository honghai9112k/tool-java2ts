export interface TimePeriod {
  startDateTime?: Date;
  endDateTime?: Date;
}
