export interface Request {
  code?: string;
  body?: string;
  method?: string;
  to?: string;
  header?: HeaderItem[];
}
