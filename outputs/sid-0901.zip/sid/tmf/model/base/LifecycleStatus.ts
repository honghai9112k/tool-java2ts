export enum LifecycleStatus {
  IN_STUDY = "In Study",
  IN_DESIGN = "In Design",
  IN_TEST = "In Test",
  ACTIVE = "Active",
  LAUNCHED = "Launched",
  RETIRED = "Retired",
  OBSOLETE = "Obsolete",
  REJECTED = "Rejected"
}
