export interface CatalogRef extends AbstractEntityRef {
  id?: string;
  refVersion?: string;
  parsedVersion?: ParsedVersion;
  href?: string;
  name?: string;
  description?: string;
  entity?: AbstractEntity;
}
