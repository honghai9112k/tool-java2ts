export interface AbstractCatalogEntity extends AbstractEntity {
  catalogId?: string;
  catalogVersion?: string;
  parsedCatalogVersion?: ParsedVersion;
}
