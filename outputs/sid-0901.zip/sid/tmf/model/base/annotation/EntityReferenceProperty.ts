// No valid class or enum found
