export interface ProductEntityFactory {
}
