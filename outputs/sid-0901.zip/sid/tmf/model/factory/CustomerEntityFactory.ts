export interface CustomerEntityFactory {
}
