export interface SaleEntityFactory {
}
