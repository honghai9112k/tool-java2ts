export interface RuleEntityFactory {
}
