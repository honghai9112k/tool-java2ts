export interface CommonEntityFactory {
}
