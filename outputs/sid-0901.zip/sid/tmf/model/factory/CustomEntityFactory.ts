export interface CustomEntityFactory {
}
