export interface ResourceEntityFactory {
}
