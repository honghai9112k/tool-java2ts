export interface PartyEntityFactory {
}
