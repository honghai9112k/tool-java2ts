export interface PolicyEntityFactory {
}
