export enum ResourceUsageStateType {
  IDLE = "idle",
  ACTIVE = "active",
  BUSY = "busy"
}
