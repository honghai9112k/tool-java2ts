export enum TaskFlowStateType {
  NEW = "new",
  ACTIVE = "active",
  HOLD = "hold",
  CANCELLED = "cancelled",
  COMPLETED = "completed"
}
