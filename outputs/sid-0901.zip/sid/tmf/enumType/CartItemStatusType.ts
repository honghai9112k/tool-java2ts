export enum CartItemStatusType {
  ACTIVE = "active",
  SAVEFORLATER = "saveForLater"
}
