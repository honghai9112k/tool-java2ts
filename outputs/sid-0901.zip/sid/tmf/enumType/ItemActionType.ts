export enum ItemActionType {
  ADD = "add",
  MODIFY = "modify",
  DELETE = "delete",
  NOCHANGE = "noChange"
}
