export enum ResourceAdministrativeStateType {
  LOCKED = "locked",
  UNLOCKED = "unlocked",
  SHUTDOWN = "shutdown"
}
