export enum IndividualStateType {
  INITIALIZED = "initialized",
  VALIDATED = "validated",
  DECEASED = "deceased"
}
