export enum ServiceOrderStateType {
  ACKNOWLEDGED = "acknowledged",
  REJECTED = "rejected",
  PENDING = "pending",
  HELD = "held",
  INPROGRESS = "inProgress",
  CANCELLED = "cancelled",
  COMPLETED = "completed",
  FAILED = "failed",
  PARTIAL = "partial",
  ASSESSINGCANCELLATION = "assessingCancellation",
  PENDINGCANCELLATION = "pendingCancellation"
}
