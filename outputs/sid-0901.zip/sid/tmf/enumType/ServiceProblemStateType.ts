export enum ServiceProblemStateType {
  ACKNOWLEDGED = "acknowledged",
  REJECTED = "rejected",
  PENDING = "pending",
  HELD = "held",
  INPROGRESS = "inProgress",
  RESOLVED = "resolved",
  CANCELLED = "cancelled",
  CLOSED = "closed"
}
