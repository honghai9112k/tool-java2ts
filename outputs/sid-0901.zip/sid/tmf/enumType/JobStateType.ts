export enum JobStateType {
  NOT_STARTED = "Not Started",
  RUNNING = "Running",
  SUCCEEDED = "Succeeded",
  FAILED = "Failed"
}
