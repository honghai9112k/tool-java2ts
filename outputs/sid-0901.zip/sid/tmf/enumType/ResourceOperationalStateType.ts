export enum ResourceOperationalStateType {
  ENABLE = "enable",
  DISABLE = "disable"
}
