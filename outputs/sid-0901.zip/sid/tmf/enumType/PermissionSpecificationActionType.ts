export enum PermissionSpecificationActionType {
  READ = "Read",
  WRITE = "Write",
  CREATE = "Create",
  UPDATE = "Update",
  DELETE = "Delete",
  READWRITE = "ReadWrite",
  AUTO_CHECK_R = "AUTO_CHECK_R",
  AUTO_CHECK_C = "AUTO_CHECK_C",
  AUTO_CHECK_U = "AUTO_CHECK_U",
  AUTO_CHECK_D = "AUTO_CHECK_D"
}
