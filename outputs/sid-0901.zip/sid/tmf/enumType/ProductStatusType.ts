export enum ProductStatusType {
  CREATED = "created",
  PENDINGACTIVE = "pendingActive",
  CANCELLED = "cancelled",
  ACTIVE = "active",
  PENDINGTERMINATE = "pendingTerminate",
  TERMINATED = "terminated",
  SUSPENDED = "suspended",
  ABORTED = "aborted ",
  PENDINGRETRYRENEWAL = "pendingRetryRenewal"
}
