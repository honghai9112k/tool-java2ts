export enum CartItemActionType {
  ADD = "add",
  MODIFY = "modify",
  DELETE = "delete",
  NOCHANGE = "noChange"
}
