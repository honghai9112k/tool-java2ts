export enum ProductOrderItemRelationshipType {
  MIGRATESTO = "migratesTo",
  BUNDLES = "bundles",
  BUNDLEDBY = "bundledBy",
  RELIESON = "reliesOn",
  ENABLES = "enables",
  REQUIRES = "requires",
  DEPENDSON = "dependsOn",
  BRINGS = "brings"
}
