export enum ServiceStateType {
  FEASIBILITYCHECKED = "feasibilityChecked",
  DESIGNED = "designed",
  RESERVED = "reserved",
  INACTIVE = "inactive",
  ACTIVE = "active",
  TERMINATED = "terminated"
}
