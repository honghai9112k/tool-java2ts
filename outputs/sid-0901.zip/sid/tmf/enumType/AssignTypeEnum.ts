export enum AssignTypeEnum {
  CLAIM = "claim",
  DELEGATE = "delegate",
  ASSIGNEE = "assignee"
}
