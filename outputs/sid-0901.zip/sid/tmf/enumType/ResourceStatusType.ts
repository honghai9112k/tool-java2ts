export enum ResourceStatusType {
  ALARM = "alarm",
  AVAILABLE = "available",
  INSTALLED = "installed",
  NOTEXISTS = "notExists",
  PENDINGREMOVAL = "pendingRemoval",
  PLANNED = "planned",
  RESERVED = "reserved",
  STANDBY = "standby",
  SUSPENDED = "suspended",
  UNKNOWN = "unknown"
}
