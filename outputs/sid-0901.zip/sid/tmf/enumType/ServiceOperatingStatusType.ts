export enum ServiceOperatingStatusType {
  PENDING = "pending",
  CONFIGURED = "configured",
  STARTING = "starting",
  RUNNING = "running",
  DEGRADED = "degraded",
  FAILED = "failed",
  LIMITED = "limited",
  STOPPING = "stopping",
  STOPPED = "stopped",
  UNKNOWN = "unknown"
}
