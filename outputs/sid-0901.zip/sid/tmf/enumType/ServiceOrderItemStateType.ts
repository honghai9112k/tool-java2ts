export enum ServiceOrderItemStateType {
  ACKNOWLEDGED = "acknowledged",
  REJECTED = "rejected",
  PENDING = "pending",
  HELD = "held",
  INPROGRESS = "inProgress",
  CANCELLED = "cancelled",
  COMPLETED = "completed",
  FAILED = "failed",
  ASSESSINGCANCELLATION = "assessingCancellation",
  PENDINGCANCELLATION = "pendingCancellation",
  PARTIAL = "partial"
}
