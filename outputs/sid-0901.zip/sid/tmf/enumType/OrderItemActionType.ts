export enum OrderItemActionType {
  ADD = "add",
  MODIFY = "modify",
  DELETE = "delete",
  NOCHANGE = "noChange"
}
