export enum PriceModelType {
  SIMPLE = "recurring",
  BLOCK = "oneTime",
  OVERAGE = "overage",
  GRADUATED = "graduated"
}
