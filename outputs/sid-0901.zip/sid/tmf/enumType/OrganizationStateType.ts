export enum OrganizationStateType {
  INITIALIZED = "initialized",
  VALIDATED = "validated",
  CLOSED = "closed"
}
