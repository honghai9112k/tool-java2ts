export enum AppointmentStateType {
  INITIALIZED = "initialized",
  CONFIRMED = "confirmed",
  CANCELLED = "cancelled",
  COMPLETED = "completed",
  FAILED = "failed"
}
