export enum ProcessFlowStateType {
  ACTIVE = "active",
  CANCELLED = "cancelled",
  HOLD = "hold",
  COMPLETED = "completed"
}
