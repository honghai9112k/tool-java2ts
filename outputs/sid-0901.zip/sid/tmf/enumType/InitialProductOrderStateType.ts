export enum InitialProductOrderStateType {
  ACKNOWLEDGED = "acknowledged",
  DRAFT = "draft"
}
