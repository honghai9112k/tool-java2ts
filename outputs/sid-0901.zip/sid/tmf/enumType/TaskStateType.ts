export enum TaskStateType {
  ACCEPTED = "accepted",
  TERMINATEDWITHERROR = "terminatedWithError",
  INPROGRESS = "inProgress",
  DONE = "done"
}
