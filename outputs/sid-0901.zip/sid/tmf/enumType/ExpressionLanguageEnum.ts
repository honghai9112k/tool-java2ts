export enum ExpressionLanguageEnum {
  TURTLE = "Turtle",
  JSON_LD = "JSON-LD",
  RDF_XML = "RDF-XML",
  OTHER = "Other"
}
