export enum DataTypeEnum {
  STRING = "String",
  BOOLEAN = "Boolean",
  INTEGER = "Integer",
  LONG = "Long",
  SHORT = "Short",
  DOUBLE = "Double",
  FLOAT = "Float",
  DATE = "Date",
  DATETIME = "DateTime",
  COLLECTION = "Collection",
  OBJECT = "Object",
  BYTES = "Bytes",
  FILE = "File",
  OTHERS = "Others"
}
