export enum PriceType {
  RECURRING = "recurring",
  ONETIME = "oneTime",
  USAGE = "usage"
}
