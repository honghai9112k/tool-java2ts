export interface BundledProductOfferingPriceRelationship extends EntityRel {
  code?: string;
  version?: string;
}
