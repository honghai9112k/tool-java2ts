export interface PolicyConditionValue extends AbstractEntity {
  value?: any;
  dataType?: string;
}
