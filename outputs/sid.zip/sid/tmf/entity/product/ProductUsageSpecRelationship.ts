export interface ProductUsageSpecRelationship extends EntityRel {
}
