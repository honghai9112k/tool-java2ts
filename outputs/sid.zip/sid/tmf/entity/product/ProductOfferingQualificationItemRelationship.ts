export interface ProductOfferingQualificationItemRelationship extends EntityRel {
  code?: string;
}
