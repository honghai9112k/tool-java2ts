export interface AdjustProductStockItem extends AbstractEntity {
  adjustProductStockQuantity?: Quantity;
  productStockTarget?: EntityRef;
  state?: string;
}
