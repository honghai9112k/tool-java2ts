export interface CheckProductStock extends AbstractEntity {
  completedCheckProductStockDate?: Date;
  creationDate?: Date;
  instantSyncCheck?: boolean;
  provideAlternative?: boolean;
  requestedAvailabilityDate?: Date;
  requestedCheckProductStockDate?: Date;
  checkProductStockItem?: CheckProductStockItem[];
  place?: EntityRef;
  relatedParty?: RelatedParty[];
  state?: string;
}
