export interface ProductConfiguration extends AbstractEntity {
  productSpecification?: EntityRef;
  product?: ProductRefOrValue;
  quantity?: number;
  productOffering?: EntityRef;
  configurationTerm?: ConfigurationTerm[];
  configurationPrice?: ConfigurationPrice[];
  isVisible?: boolean;
  configurationAction?: ConfigurationAction[];
  bundledProductOfferingOption?: BundledProductOfferingOption;
  isSelected?: boolean;
  productConfigurationItem?: ProductConfiguration[];
  bundledGroupProductOffering?: BundledGroupProductOffering;
  isSelectable?: boolean;
  configurationCharacteristic?: ConfigurationCharacteristic[];
  policy?: EntityRef[];
  relatedParty?: RelatedParty[];
  quote?: Quote;
  computedProductConfigurationItem?: ProductConfigurationItem[];
}
