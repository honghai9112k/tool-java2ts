export interface ProductOfferingPriceRelationship extends EntityRel {
  code?: string;
}
