export interface ConfigurationAction extends AbstractEntity {
  isSelected?: boolean;
  action?: string;
}
