export interface PromotionAssignment extends AbstractEntity {
  promotion?: EntityRef[];
  targetRef?: { [key: string]: EntityRef[] };
  targetProductOffering?: EntityRef[];
  targetChannel?: EntityRef[];
  targetMarketSegment?: EntityRef[];
  targetBuyerGroup?: string[];
  startDate?: Date;
  endDate?: Date;
  status?: string;
  rules?: AssignmentRule[];
  description?: string;
}
