export interface PromotionCriteria extends AbstractEntity {
  criteriaOperator?: string;
  criteriaParameter?: string;
  criteriaValue?: string;
}
