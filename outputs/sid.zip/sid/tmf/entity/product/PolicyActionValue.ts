export interface PolicyActionValue extends AbstractEntity {
  dataType?: string;
  value?: any;
}
