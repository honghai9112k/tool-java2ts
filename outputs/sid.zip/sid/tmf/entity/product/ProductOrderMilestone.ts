export interface ProductOrderMilestone extends Milestone {
  productOrderItem?: EntityRef[];
}
