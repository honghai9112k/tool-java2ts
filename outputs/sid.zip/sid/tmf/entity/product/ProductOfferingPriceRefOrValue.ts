export interface ProductOfferingPriceRefOrValue extends EntityRefOrValue {
}
