export interface PolicyActionPromotion extends PolicyAction {
}
