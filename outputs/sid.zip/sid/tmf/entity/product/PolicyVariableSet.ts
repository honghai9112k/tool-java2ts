export interface PolicyVariableSet extends AbstractEntity {
  variable?: EntityRef[];
}
