export interface AlternateProductStock extends AbstractEntity {
  alternateAvailabilityDate?: Date;
  alternatePlace?: EntityRef;
  alternateProduct?: ProductRefOrValue;
  alternateQuantity?: Quantity;
  alternateStock?: EntityRef;
}
