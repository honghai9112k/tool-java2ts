export interface PolicyCondition extends AbstractEntity {
  note?: Note[];
  policyConditionStatement?: PolicyConditionStatement[];
  policyCondition?: PolicyCondition[];
  isConjustiveNormalForm?: boolean;
  creationDate?: Date;
  policyConditionStrategy?: string;
}
