export interface ProductOfferingQualification extends AbstractEntity {
  note?: Note[];
  channel?: EntityRef;
  requestedQualificationCompletionDate?: Date;
  provideAlternative?: boolean;
  relatedParty?: RelatedParty[];
  creationDate?: Date;
  provideOnlyAvailable?: boolean;
  instantSyncQualification?: boolean;
  qualificationResult?: string;
  effectiveQualificationDate?: Date;
  productOfferingQualificationItem?: ProductOfferingQualificationItem[];
  provideResultReason?: boolean;
  expectedQualificationCompletionDate?: Date;
  state?: string;
  expirationDate?: Date;
  place?: EntityRef;
  searchCriteria?: ProductOfferingQualificationItem;
}
