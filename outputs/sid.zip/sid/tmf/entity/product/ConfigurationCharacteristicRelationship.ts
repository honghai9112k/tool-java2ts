export interface ConfigurationCharacteristicRelationship extends EntityRel {
}
