export interface AdjustProductStock extends AbstractEntity {
  adjustReason?: string;
  completedAdjustProductStockDate?: Date;
  creationDate?: Date;
  instantSyncAdjust?: boolean;
  requestedAdjustProductStockDate?: Date;
  adjustProductStockItem?: AdjustProductStockItem[];
  state?: string;
}
