export interface ProductUsageSpecification extends AbstractEntity {
  isBundle?: boolean;
  productSpecification?: EntityRef[];
  specCharacteristic?: CharacteristicSpecification[];
  bundledProductUsageSpecification?: EntityRef[];
  productUsageSpecRelationship?: ProductUsageSpecRelationship[];
  attachment?: EntityRef[];
  resourceUsageSpecification?: EntityRef[];
  serviceUsageSpecification?: EntityRef[];
}
