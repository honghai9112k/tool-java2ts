export interface ProductOfferingTerm extends AbstractEntity {
  duration?: Duration;
}
