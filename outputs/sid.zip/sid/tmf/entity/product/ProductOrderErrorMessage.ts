export interface ProductOrderErrorMessage extends AbstractEntity {
  reason?: string;
  message?: string;
  referenceError?: string;
  productOrderItem?: EntityRef[];
  status?: string;
  timestamp?: Date;
}
