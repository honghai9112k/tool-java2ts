export interface ProductSpecification extends AbstractCatalogEntity {
  isBundle?: boolean;
  productSpecCharacteristic?: CharacteristicSpecification[];
  intentSpecification?: EntityRef;
  targetProductSchema?: EntityRef;
  serviceSpecification?: EntityRef[];
  resourceSpecification?: EntityRef[];
  productNumber?: string;
  relatedParty?: RelatedParty[];
  attachment?: AttachmentRefOrValue[];
  bundledProductSpecification?: BundledProductSpecification[];
  productSpecificationRelationship?: ProductSpecificationRelationship[];
  externalIdentifier?: ExternalIdentifier[];
  category?: EntityRef[];
  brand?: string;
  isTemplate?: boolean;
  policy?: EntityRef[];
}
