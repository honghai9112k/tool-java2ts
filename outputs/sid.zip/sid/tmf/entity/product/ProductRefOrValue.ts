export interface ProductRefOrValue extends EntityRefOrValue {
}
