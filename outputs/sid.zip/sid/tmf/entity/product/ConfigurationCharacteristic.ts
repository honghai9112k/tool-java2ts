export interface ConfigurationCharacteristic extends AbstractEntity {
  minCardinality?: number;
  regex?: string;
  configurationCharacteristicValue?: ConfigurationCharacteristicValue[];
  isConfigurable?: boolean;
  valueType?: string;
  maxCardinality?: number;
  configurationCharacteristicRelationship?: ConfigurationCharacteristicRelationship[];
}
