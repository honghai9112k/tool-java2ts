export interface Category extends AbstractCatalogEntity {
  parent?: EntityRef;
  subCategory?: EntityRef[];
  isRoot?: boolean;
  productOffering?: EntityRef[];
  isTemplate?: boolean;
}
