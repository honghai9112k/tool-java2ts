export interface PolicyConditionVariable extends AbstractEntity {
  fields?: string;
  filter?: string;
  path?: string;
  dataType?: string;
  variableType?: string;
}
