export interface CancelProductOrder extends AbstractEntity {
  productOrder?: EntityRef;
  requestedCancellationDate?: Date;
  state?: string;
  creationDate?: Date;
  cancellationReason?: string;
  effectiveCancellationDate?: Date;
}
