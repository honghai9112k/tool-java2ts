export interface PriceAlteration extends AbstractEntity {
  applicationDuration?: number;
  unitOfMeasure?: string;
  price?: Price;
  priceType?: string;
  productOfferingPrice?: EntityRef;
  priority?: number;
  recurringChargePeriod?: string;
}
