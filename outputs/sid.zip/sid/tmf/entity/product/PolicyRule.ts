export interface PolicyRule extends AbstractEntity {
  note?: Note[];
  policyAction?: EntityRef[];
  policyCondition?: EntityRef;
  isConjustiveNormalForm?: boolean;
  sequencedAction?: number;
  creationDate?: Date;
  relatedParty?: RelatedParty[];
  policyEvent?: EntityRef;
  sequencedValue?: number;
  policyDomain?: EntityRef[];
  executionStrategy?: string;
  state?: string;
}
