export interface ProductConfigurationItemRelationship extends EntityRel {
  code?: string;
}
