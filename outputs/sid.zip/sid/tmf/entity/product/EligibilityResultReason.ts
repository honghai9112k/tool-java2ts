export interface EligibilityResultReason extends AbstractEntity {
  label?: string;
}
