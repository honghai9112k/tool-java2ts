export interface Catalog extends AbstractEntity {
  catalogType?: string;
  relatedParty?: RelatedParty[];
}
