export interface QueryProductConfigurationItem extends AbstractEntity {
  productConfigurationItemRelationship?: ProductConfigurationItemRelationship[];
  queryProductConfigurationItem?: QueryProductConfigurationItem[];
  productConfiguration?: ProductConfiguration;
  state?: string;
  contextItem?: EntityRef;
  stateReason?: StateReason[];
}
