export interface ProductSpecificationRelationship extends EntityRel {
  code?: string;
  characteristic?: CharacteristicSpecification[];
}
