export interface CheckProductOfferingQualificationAttributeValueChangePayload {
  code?: string;
  checkProductOfferingQualification?: CheckProductOfferingQualification;
}
