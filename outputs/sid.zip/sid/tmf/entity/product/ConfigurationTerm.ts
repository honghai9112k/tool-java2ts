export interface ConfigurationTerm extends AbstractEntity {
  duration?: Duration;
  isSelected?: boolean;
  isSelectable?: boolean;
}
