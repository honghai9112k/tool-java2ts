export interface ProductStockRelationship extends EntityRel {
  code?: string;
  stockLevel?: EntityRef;
}
