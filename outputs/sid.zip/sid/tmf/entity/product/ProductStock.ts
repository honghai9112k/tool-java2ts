export interface ProductStock extends AbstractEntity {
  creationDate?: Date;
  lastInventoryDate?: Date;
  replenishmentDate?: Date;
  stockLevelCategory?: string;
  channel?: EntityRef[];
  marketSegment?: EntityRef[];
  maxStockLevel?: Quantity;
  minStockLevel?: Quantity;
  place?: EntityRef;
  productStockLevel?: Quantity;
  productStockRelationship?: ProductStockRelationship[];
  productStockStatusType?: string;
  productStockUsageType?: string;
  relatedParty?: RelatedParty[];
  reorderQuantity?: Quantity;
  resource?: EntityRef[];
  stockLevelAlert?: Quantity;
  stockedProduct?: ProductRefOrValue;
}
