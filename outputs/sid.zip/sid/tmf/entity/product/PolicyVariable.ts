export interface PolicyVariable extends AbstractEntity {
  fields?: string;
  filter?: string;
  path?: string;
  operator?: string[];
  dataType?: string;
  variableType?: string;
  layout?: Layout;
  parent?: EntityRef;
}
