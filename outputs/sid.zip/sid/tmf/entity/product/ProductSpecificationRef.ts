export interface ProductSpecificationRef extends EntityRef {
  targetProductSchema?: TargetProductSchema;
}
