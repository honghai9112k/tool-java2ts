export interface BundledProductOfferingOption extends AbstractEntity {
  numberRelOfferDefault?: number;
  numberRelOfferLowerLimit?: number;
  numberRelOfferUpperLimit?: number;
}
