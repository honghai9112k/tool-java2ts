export interface PolicyEvent extends AbstractEntity {
  creationDate?: Date;
  event?: EntityRef[];
  query?: string;
  eventType?: string;
}
