export interface EligibilityUnavailabilityReason extends AbstractEntity {
  label?: string;
}
