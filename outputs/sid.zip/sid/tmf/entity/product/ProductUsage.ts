export interface ProductUsage extends AbstractEntity {
  isBundle?: boolean;
  bundledProductUsage?: EntityRef[];
  product?: EntityRef;
  serviceUsage?: EntityRef[];
  resourceUsage?: EntityRef[];
  relatedParty?: RelatedParty[];
  ratedProductUsage?: RatedProductUsage[];
  usageDate?: Date;
  usageSpecification?: EntityRef;
  externalIdentifier?: ExternalIdentifier[];
  usageCharacteristic?: Characteristic[];
  status?: string;
  usageType?: string;
}
