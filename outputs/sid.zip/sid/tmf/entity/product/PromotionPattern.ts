export interface PromotionPattern extends AbstractEntity {
  priority?: number;
  relationTypeAmongGroup?: string;
  action?: PromotionAction[];
  criteriaGroup?: PromotionCriteriaGroup[];
}
