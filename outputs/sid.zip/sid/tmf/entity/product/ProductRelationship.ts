export interface ProductRelationship extends EntityRel {
  code?: string;
}
