export interface ProductOfferingPrice extends AbstractEntity {
  isBundle?: boolean;
  prodSpecCharValueUse?: CharacteristicSpecification[];
  popRelationship?: ProductOfferingPriceRelationship[];
  unitOfMeasure?: Quantity;
  priceType?: string;
  recurringChargePeriodType?: string;
  tax?: TaxItem[];
  recurringChargePeriodLength?: number;
  pricingLogicAlgorithm?: PricingLogicAlgorithm[];
  price?: Money;
  percentage?: number;
  externalIdentifier?: ExternalIdentifier[];
  place?: EntityRef[];
  bundledPopRelationship?: EntityRef[];
  productOfferingTerm?: ProductOfferingTerm[];
  isTemplate?: boolean;
  policy?: EntityRef[];
  priceOption?: string;
  tier?: TieredPrice[];
  priceMode?: string;
}
