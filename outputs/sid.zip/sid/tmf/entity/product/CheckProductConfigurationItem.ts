export interface CheckProductConfigurationItem extends AbstractEntity {
  productConfigurationItemRelationship?: ProductConfigurationItemRelationship[];
  productConfiguration?: ProductConfiguration;
  state?: string;
  contextItem?: EntityRef;
  productConfigurationItem?: CheckProductConfigurationItem[];
  alternateProductConfigurationProposal?: ProductConfiguration[];
  stateReason?: StateReason[];
}
