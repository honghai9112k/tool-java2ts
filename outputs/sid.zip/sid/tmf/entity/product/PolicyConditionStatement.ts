export interface PolicyConditionStatement extends AbstractEntity {
  opType?: string;
  policyConditionValue?: PolicyConditionValue[];
  policyConditionVariable?: PolicyConditionVariable;
}
