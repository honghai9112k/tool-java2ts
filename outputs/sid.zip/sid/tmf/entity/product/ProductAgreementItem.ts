export interface ProductAgreementItem extends AgreementItem {
  termOrCondition?: AgreementTermOrCondition[];
  product?: EntityRef[];
  productOffering?: EntityRef[];
}
