export interface PolicyAction extends AbstractEntity {
  note?: Note[];
  policyAction?: PolicyAction[];
  actionCondition?: EntityRef[];
  actionStrategy?: string;
  actionType?: string;
  actionSequence?: number;
  creationDate?: Date;
  alarm?: Alarm;
  filter?: string;
  path?: string;
  fields?: string;
  operation?: string;
  actionValue?: PolicyActionValue;
  event?: Event;
  actionEntityRef?: EntityRef;
}
