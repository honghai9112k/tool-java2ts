export interface PromotionAction extends AbstractEntity {
  actionEntityRef?: EntityRef;
  actionType?: string;
  actionValue?: string;
}
