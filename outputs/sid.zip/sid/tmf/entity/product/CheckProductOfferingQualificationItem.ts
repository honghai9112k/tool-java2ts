export interface CheckProductOfferingQualificationItem extends AbstractEntity {
  note?: Note[];
  product?: ProductRefOrValue;
  qualificationItemRelationship?: ProductOfferingQualificationItemRelationship[];
  productOffering?: EntityRef;
  alternateProductOfferingProposal?: AlternateProductOfferingProposal[];
  terminationError?: TerminationError[];
  action?: string;
  eligibilityResultReason?: EligibilityResultReason[];
  qualificationItemResult?: string;
  state?: string;
  expectedActivationDate?: Date;
  category?: EntityRef;
  promotion?: EntityRef;
}
