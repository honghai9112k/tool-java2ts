export interface CheckProductConfiguration extends AbstractEntity {
  instantSync?: boolean;
  contextEntity?: EntityRef;
  provideAlternatives?: boolean;
  checkProductConfigurationItem?: CheckProductConfigurationItem[];
  channel?: EntityRef;
  contextCharacteristic?: Characteristic[];
  state?: string;
  relatedParty?: RelatedParty[];
}
