export interface BundledGroupProductOffering extends AbstractEntity {
  bundledGroupProductOffering?: BundledGroupProductOffering[];
  bundledProductOffering?: BundledProductOffering[];
  bundledGroupProductOfferingOption?: BundledGroupProductOfferingOption;
}
