export interface ConfigurationCharacteristicValue extends AbstractEntity {
  rangeInterval?: string;
  regex?: string;
  valueTo?: number;
  unitOfMeasure?: string;
  isSelected?: boolean;
  isSelectable?: boolean;
  characteristicValue?: Characteristic;
  valueFrom?: number;
}
