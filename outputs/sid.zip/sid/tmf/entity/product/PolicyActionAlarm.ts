export interface PolicyActionAlarm extends PolicyAction {
}
