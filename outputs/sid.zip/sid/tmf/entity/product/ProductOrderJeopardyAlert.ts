export interface ProductOrderJeopardyAlert extends JeopardyAlert {
  productOrderItem?: EntityRef[];
}
