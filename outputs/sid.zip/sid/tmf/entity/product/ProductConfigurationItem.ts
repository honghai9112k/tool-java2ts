export interface ProductConfigurationItem extends AbstractEntity {
  productConfigurationItemRelationship?: ProductConfigurationItemRelationship[];
  productConfiguration?: ProductConfiguration;
  state?: string;
  contextItem?: EntityRef;
  productConfigurationItem?: ProductConfigurationItem[];
  alternateProductConfigurationProposal?: ProductConfiguration[];
  stateReason?: StateReason[];
}
