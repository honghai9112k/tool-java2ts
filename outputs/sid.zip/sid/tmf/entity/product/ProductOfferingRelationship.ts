export interface ProductOfferingRelationship extends EntityRel {
  code?: string;
}
