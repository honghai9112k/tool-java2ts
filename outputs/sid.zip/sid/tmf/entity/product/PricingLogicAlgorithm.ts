export interface PricingLogicAlgorithm extends AbstractEntity {
  plaSpecId?: string;
}
