export interface CheckProductOfferingQualification extends AbstractEntity {
  note?: Note[];
  channel?: EntityRef;
  requestedQualificationCompletionDate?: Date;
  provideAlternative?: boolean;
  relatedParty?: RelatedParty[];
  creationDate?: Date;
  provideOnlyAvailable?: boolean;
  instantSyncQualification?: boolean;
  qualificationResult?: string;
  effectiveQualificationDate?: Date;
  checkProductOfferingQualificationItem?: CheckProductOfferingQualificationItem[];
  provideResultReason?: boolean;
  expectedQualificationCompletionDate?: Date;
  state?: string;
  expirationDate?: Date;
}
