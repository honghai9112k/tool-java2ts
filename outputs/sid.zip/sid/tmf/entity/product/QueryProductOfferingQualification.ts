export interface QueryProductOfferingQualification extends AbstractEntity {
  note?: Note[];
  qualifiedProductOfferingItem?: QueryProductOfferingQualificationItem[];
  searchCriteria?: QueryProductOfferingQualificationItem;
  channel?: EntityRef;
  requestedQualificationCompletionDate?: Date;
  relatedParty?: RelatedParty[];
  creationDate?: Date;
  instantSyncQualification?: boolean;
  effectiveQualificationDate?: Date;
  expectedQualificationCompletionDate?: Date;
  state?: string;
  expirationDate?: Date;
}
