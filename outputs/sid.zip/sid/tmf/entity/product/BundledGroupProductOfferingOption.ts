export interface BundledGroupProductOfferingOption extends AbstractEntity {
  numberRelOfferLowerLimit?: number;
  numberRelOfferUpperLimit?: number;
}
