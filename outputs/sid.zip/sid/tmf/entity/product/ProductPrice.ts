export interface ProductPrice extends AbstractEntity {
  unitOfMeasure?: string;
  price?: Price;
  priceType?: string;
  productOfferingPrice?: EntityRef;
  recurringChargePeriod?: string;
  priceAlteration?: PriceAlteration[];
}
