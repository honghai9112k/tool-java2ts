export interface QueryProductConfiguration extends AbstractEntity {
  instantSync?: boolean;
  contextEntity?: EntityRef;
  channel?: EntityRef;
  computedProductConfigurationItem?: QueryProductConfigurationItem[];
  contextCharacteristic?: Characteristic[];
  requestProductConfigurationItem?: QueryProductConfigurationItem[];
  state?: string;
  relatedParty?: RelatedParty[];
}
