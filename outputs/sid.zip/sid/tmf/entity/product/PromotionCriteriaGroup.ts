export interface PromotionCriteriaGroup extends AbstractEntity {
  criteria?: PromotionCriteria[];
  groupName?: string;
  criteriaLogicalRelationship?: string;
}
