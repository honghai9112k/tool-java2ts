export interface QueryProductOfferingQualificationAttributeValueChangePayload {
  code?: string;
  queryProductOfferingQualification?: QueryProductOfferingQualification;
}
