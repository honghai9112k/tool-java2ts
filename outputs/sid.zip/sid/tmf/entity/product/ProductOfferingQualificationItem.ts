export interface ProductOfferingQualificationItem extends AbstractEntity {
  note?: Note[];
  product?: ProductRefOrValue;
  qualificationItemRelationship?: ProductOfferingQualificationItemRelationship[];
  productOffering?: EntityRef;
  alternateProductOfferingProposal?: AlternateProductOfferingProposal[];
  terminationError?: TerminationError[];
  action?: string;
  eligibilityResultReason?: EligibilityResultReason[];
  qualificationItemResult?: string;
  state?: string;
  expectedActivationDate?: Date;
  productOfferingQualificationItem?: ProductOfferingQualificationItem[];
  category?: EntityRef;
  promotion?: EntityRef;
}
