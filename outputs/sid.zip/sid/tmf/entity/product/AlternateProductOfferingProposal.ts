export interface AlternateProductOfferingProposal extends AbstractEntity {
  alternateActivationDate?: Date;
  alternateProduct?: EntityRef;
  alternateProductOffering?: EntityRef;
  promotion?: EntityRef;
}
