export interface CheckProductStockItem extends AbstractEntity {
  availabilityResult?: string;
  provideAlternative?: boolean;
  alternate?: AlternateProductStock[];
  checkedProductStock?: ProductStock;
  requestedQuantity?: Quantity;
  state?: string;
}
