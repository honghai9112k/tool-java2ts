export interface AllowedProductAction extends AbstractEntity {
  channel?: EntityRef[];
  action?: string;
}
