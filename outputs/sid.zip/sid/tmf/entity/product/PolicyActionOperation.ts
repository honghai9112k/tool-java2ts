export interface PolicyActionOperation extends PolicyAction {
}
