export interface ProductValue extends AbstractEntity {
  isBundle?: boolean;
  productSpecification?: EntityRef;
  productCharacteristic?: Characteristic[];
  billingAccount?: EntityRef;
  productOrderItem?: RelatedOrderItem[];
  realizingService?: EntityRef[];
  terminationDate?: Date;
  realizingResource?: EntityRef[];
  place?: EntityRef[];
  agreementItem?: EntityRef[];
  product?: ProductRefOrValue[];
  productOffering?: EntityRef;
  creationDate?: Date;
  productTerm?: ProductTerm[];
  relatedParty?: RelatedParty[];
  productSerialNumber?: string;
  productRelationship?: ProductRelationship[];
  isCustomerVisible?: boolean;
  orderDate?: Date;
  productPrice?: ProductPrice[];
  startDate?: Date;
  status?: string;
}
