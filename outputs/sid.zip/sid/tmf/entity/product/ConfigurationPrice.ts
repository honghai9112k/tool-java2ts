export interface ConfigurationPrice extends AbstractEntity {
  unitOfMeasure?: string;
  price?: Price;
  priceType?: string;
  productOfferingPrice?: EntityRef;
  recurringChargePeriod?: Quantity;
  priceAlteration?: PriceAlteration[];
}
