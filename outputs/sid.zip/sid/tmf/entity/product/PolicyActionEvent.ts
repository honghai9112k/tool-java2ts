export interface PolicyActionEvent extends PolicyAction {
}
