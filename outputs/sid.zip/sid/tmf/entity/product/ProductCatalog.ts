export interface ProductCatalog extends Catalog {
  category?: EntityRef[];
}
