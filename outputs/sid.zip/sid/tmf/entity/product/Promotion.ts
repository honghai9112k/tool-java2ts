export interface Promotion extends AbstractEntity {
  pattern?: PromotionPattern[];
  type?: string;
  isTemplate?: boolean;
}
