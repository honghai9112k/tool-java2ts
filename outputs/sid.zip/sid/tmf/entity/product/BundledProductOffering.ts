export interface BundledProductOffering extends EntityRef {
  bundledProductOfferingOption?: BundledProductOfferingOption;
}
