export interface BundledProductSpecification extends AbstractEntity {
}
