export interface CancelOrder extends AbstractEntity {
  requestedCancellationDate?: Date;
  state?: string;
  cancellationReason?: string;
  effectiveCancellationDate?: Date;
}
