export interface PcrfGroupInfo extends AbstractEntity {
  msisdn?: string;
  serviceId?: string;
  status?: string;
  groupId?: string;
  productId?: string;
}
