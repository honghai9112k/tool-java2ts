export interface RaciMatrix {
  name?: string;
  matrix?: Matrix;
}
