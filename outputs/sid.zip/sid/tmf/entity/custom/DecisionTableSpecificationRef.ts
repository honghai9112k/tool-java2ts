export interface DecisionTableSpecificationRef extends EntityRef {
  value?: string;
  version?: string;
  validFor?: TimePeriod;
}
