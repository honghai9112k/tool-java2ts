export interface CharacteristicCatalog extends AbstractEntity {
  attributes?: EntityRef[];
}
