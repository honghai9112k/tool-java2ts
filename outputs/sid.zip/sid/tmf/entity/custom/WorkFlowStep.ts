export interface WorkFlowStep {
  stepId?: string;
  name?: string;
  status?: string;
  startDate?: Date;
  extData?: string;
}
