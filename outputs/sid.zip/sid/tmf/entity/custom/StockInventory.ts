export interface StockInventory extends AbstractEntity {
  availableQuantity?: number;
  standByQuantity?: number;
  reservedQuantity?: number;
  suspendedQuantity?: number;
  pendingRemovalQuantity?: number;
  resourceSpecification?: ResourceSpecificationRef;
  stockLocation?: EntityRef;
  stockSystem?: EntityRef;
}
