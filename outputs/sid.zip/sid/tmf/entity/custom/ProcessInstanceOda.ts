export interface ProcessInstanceOda extends AbstractEntity {
  businessId?: string;
  businessType?: string;
  tenantId?: string;
  odaProcessDefinitionId?: string;
  extendFields?: ExtendFields[];
  engineProcessInstanceInfo?: EngineProcessInstanceInfo;
  audit?: Audit;
  businessDetailUrl?: string;
}
