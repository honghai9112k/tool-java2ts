export interface VanityLines extends AbstractEntity {
  priorityLevel?: number;
  prefix?: string;
  regexPattern?: string;
  status?: string;
}
