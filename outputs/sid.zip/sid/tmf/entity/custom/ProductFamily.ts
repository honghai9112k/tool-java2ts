export interface ProductFamily extends AbstractEntity {
  extData?: string;
}
