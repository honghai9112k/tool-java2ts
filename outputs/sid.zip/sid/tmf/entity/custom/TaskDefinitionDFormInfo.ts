export interface TaskDefinitionDFormInfo {
  dueDate?: string;
  dFormName?: string;
  taskDFormPermission?: TaskDFormPermission;
  dFormDefinitionCode?: string;
  dFormDefinitionFullSpec?: string;
  extendFields?: ExtendFields[];
}
