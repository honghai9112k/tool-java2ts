export interface Actions {
  view?: boolean;
  delete?: boolean;
}
