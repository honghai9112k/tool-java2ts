export interface EngineCurrentTaskInstanceInfo {
  engineProcessInstanceId?: string;
  engineTaskInstanceId?: string;
  engineTaskDefinitionId?: string;
  engineExecutionId?: string;
  globalVariables?: ExtendFields[];
  localVariables?: ExtendFields[];
  customVariables?: ExtendFields[];
}
