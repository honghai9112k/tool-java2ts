export interface EngineProcessInstanceInfo {
  engineBusinessKey?: string;
  engineProcessDefinitionId?: string;
  engineProcessInstanceId?: string;
  engineProcessInstanceName?: string;
  engineProcessInstanceVariable?: ExtendFields[];
  extendFields?: ExtendFields[];
}
