export interface TaskInstanceOda extends AbstractEntity {
  odaProcessInstanceId?: string;
  extendFields?: ExtendFields[];
  odaTaskDefinitionId?: string;
  odaTaskDefinitionCode?: string;
  engineCurrentTaskInstanceInfo?: EngineCurrentTaskInstanceInfo;
  tenantId?: string;
  audit?: Audit;
  assigneeUser?: string;
  owner?: string;
  candidateGroups?: string[];
  candidateUsers?: string[];
  assignType?: AssignTypeEnum;
  dueDate?: string;
  taskInstanceDFormInfos?: TaskInstanceDFormInfo[];
  icon?: string;
  businessDetailUrl?: string;
}
