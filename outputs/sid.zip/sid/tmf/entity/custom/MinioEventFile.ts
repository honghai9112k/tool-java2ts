export interface MinioEventFile extends AbstractEntity {
  fileName?: string;
  fileType?: string;
  source?: string;
  uploadedAt?: Date;
  processAt?: Date;
  statusProcess?: boolean;
  url?: string;
}
