export interface AssignmentRule extends AbstractEntity {
  ruleType?: string;
  operator?: string;
  value?: string;
}
