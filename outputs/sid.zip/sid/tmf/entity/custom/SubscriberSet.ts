export interface SubscriberSet extends AbstractEntity {
}
