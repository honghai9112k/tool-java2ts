export interface TaskInstanceDFormInfo {
  taskDefinitionDFormInfo?: TaskDefinitionDFormInfo;
  dFormData?: string;
}
