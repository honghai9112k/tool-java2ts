export interface CommunityGroup extends AbstractEntity {
  startIndex?: number;
  endIndex?: number;
}
