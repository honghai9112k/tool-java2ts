export interface ProductLine extends AbstractEntity {
  productFamily?: ProductFamily;
  extData?: string;
}
