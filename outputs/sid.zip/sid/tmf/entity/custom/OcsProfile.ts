export interface OcsProfile extends AbstractEntity {
}
