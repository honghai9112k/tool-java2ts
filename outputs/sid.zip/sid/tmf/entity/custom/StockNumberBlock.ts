export interface StockNumberBlock extends AbstractEntity {
  relatedParty?: RelatedParty[];
  vanityLine?: EntityRef;
  stockSystem?: EntityRef;
  numberRangeFrom?: string;
  numberRangeTo?: string;
  createdBy?: EntityRef;
  createdDate?: Date;
}
