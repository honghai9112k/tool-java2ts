export interface ProposalSpecificationRefOrValue extends EntityRefOrValue {
}
