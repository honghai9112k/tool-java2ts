export interface RejectionReason extends AbstractEntity {
  reason?: string;
}
