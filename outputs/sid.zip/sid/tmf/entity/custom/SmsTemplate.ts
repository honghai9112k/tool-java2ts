export interface SmsTemplate extends AbstractEntity {
  type?: string;
  subsType?: string;
  action?: string;
  status?: number;
  errorCode?: string;
  targetType?: number;
  order?: number;
  quantity?: string;
  value?: string;
  relationship?: SmsTemplateRelationship[];
}
