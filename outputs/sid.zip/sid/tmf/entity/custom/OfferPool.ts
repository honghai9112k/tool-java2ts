export interface OfferPool extends AbstractEntity {
  rfsCode?: string;
  offerId?: string;
  daId?: string;
  status?: string;
  offerType?: string;
  offerName?: string;
}
