export interface StockLocation extends AbstractEntity {
  parent?: EntityRef;
  type?: string;
  status?: string;
  phoneNumber?: string;
  place?: RelatedPlaceRefOrValue[];
  relatedParty?: RelatedParty[];
  stockSystem?: EntityRef;
}
