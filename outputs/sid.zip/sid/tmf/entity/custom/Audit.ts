export interface Audit {
  createdUserName?: string;
  createdUserId?: string;
}
