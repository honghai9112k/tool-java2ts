export interface ExtendFields {
  key?: any;
  value?: any;
  valueType?: DataTypeEnum;
  description?: string;
}
