export interface PickListItemValue extends AbstractEntity {
  label?: string;
  url?: string;
}
