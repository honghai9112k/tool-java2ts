export interface ProposalSpecification extends AbstractEntity {
  shortDescription?: string;
  serviceSpecification?: EntityRef;
  attribute?: ProposalAttribute[];
  policyAction?: EntityRef;
  policyCondition?: EntityRef;
  productOfferingPrice?: EntityRef;
  parent?: EntityRef;
  extData?: string;
  policyStatement?: EntityRef;
}
