export interface ProductProperty extends AbstractEntity {
  parentCode?: string;
  productGroup?: EntityRef;
  productPropertySpecification?: EntityRef;
  propertyCount?: number;
  productPropertyItem?: string[];
  serviceCode?: string;
  serviceType?: string;
  packageId?: string;
}
