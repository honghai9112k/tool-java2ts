export interface StockCheckPlan extends AbstractEntity {
  status?: string;
  createdDate?: Date;
  createdBy?: EntityRef;
  stockLocation?: EntityRef;
  stockSystem?: EntityRef;
  resourceSpecification?: ResourceSpecificationRef[];
}
