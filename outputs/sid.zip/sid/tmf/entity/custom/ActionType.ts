export interface ActionType extends AbstractEntity {
  dataType?: string;
  layout?: Layout;
  referenceType?: string;
  referenceCtlType?: string;
}
