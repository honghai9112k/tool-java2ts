export interface PropertySpecification extends AbstractEntity {
  dataType?: string;
  itemIndex?: number;
  layout?: Layout;
}
