export interface OutboxEvent extends AbstractEntity {
  body?: string;
  createDate?: Date;
  modifyDate?: Date;
  state?: string;
  retryCount?: number;
}
