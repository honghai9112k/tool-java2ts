export interface ProductGroup extends AbstractEntity {
}
