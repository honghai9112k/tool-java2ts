export interface Arpu extends AbstractEntity {
}
