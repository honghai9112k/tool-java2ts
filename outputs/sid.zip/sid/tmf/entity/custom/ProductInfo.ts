export interface ProductInfo extends AbstractEntity {
  systemCode?: string;
  serviceCode?: string;
  createDate?: Date;
  accumulateQuantity?: number;
  commitmentQuantity?: number;
  extendable?: boolean;
  retryRenewalCount?: number;
  retryPeriod?: number;
  code?: string;
  cycleType?: string;
  originQuantity?: number;
  quantity?: number;
  cycleCount?: number;
  productProperties?: string[];
  startDate?: Date;
  endDate?: Date;
}
