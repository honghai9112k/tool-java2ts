export interface OrderRequest extends AbstractEntity {
  msisdn?: string;
  actionType?: string;
  serviceCode?: string;
  transReqId?: string;
  transCpId?: string;
  source?: string;
  isSync?: number;
  otherInfo?: string;
  hrmCode?: string;
  messRequest?: string;
  quantity?: number;
  packageId?: string;
  serviceDataCode?: string;
  location?: string;
  transactionId?: string;
  agentCode?: string;
  subscriberType?: string;
  msisdnMember?: string;
  msisdnChange?: string;
  requestDate?: Date;
  requestStatus?: string;
  productId?: string;
  productOrderId?: string;
}
