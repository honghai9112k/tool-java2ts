export interface TaskDFormPermission {
  owner?: string;
  sharedUsers?: string[];
  sharedGroups?: string[];
}
