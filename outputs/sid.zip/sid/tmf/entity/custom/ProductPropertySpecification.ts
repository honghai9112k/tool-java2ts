export interface ProductPropertySpecification extends AbstractEntity {
  propertySpecification?: PropertySpecification[];
  propertyCount?: number;
}
