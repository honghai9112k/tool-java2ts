export interface ProcessSpecification extends AbstractEntity {
  domain?: string;
  processType?: string;
  businessProcess?: string;
  businessProcessInfo?: BusinessProcessInfo;
  channel?: EntityRef[];
  relatedParty?: RelatedParty[];
  taskFlowSpecification?: EntityRef[];
  functionCode?: string;
  tenantId?: string;
}
