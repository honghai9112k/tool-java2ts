export interface StockCheckTicket extends AbstractEntity {
  status?: string;
  actualTime?: Date;
  stockCheckPlan?: EntityRef;
  stockLocation?: EntityRef;
  createdBy?: EntityRef;
  resourceSpecification?: ResourceSpecificationRef[];
}
