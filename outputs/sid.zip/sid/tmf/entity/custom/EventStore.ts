export interface EventStore extends AbstractEntity {
  objectId?: string;
  eventType?: string;
  resourceType?: string;
  eventTime?: Date;
  body?: string;
  createDate?: Date;
}
