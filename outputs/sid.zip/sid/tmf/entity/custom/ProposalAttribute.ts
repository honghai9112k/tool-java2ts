export interface ProposalAttribute {
  code?: string;
  idx?: string;
  name?: string;
  valueType?: string;
  pickList?: string;
  attributeValue?: CharacteristicValueSpecification[];
  layout?: Layout;
  extData?: string;
}
