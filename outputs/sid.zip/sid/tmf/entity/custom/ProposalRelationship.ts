export interface ProposalRelationship extends EntityRel {
  version?: string;
}
