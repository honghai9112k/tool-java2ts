export interface LogRequestInfo extends AbstractEntity {
  productId?: string;
  requestInfo?: string;
  productOrderId?: string;
}
