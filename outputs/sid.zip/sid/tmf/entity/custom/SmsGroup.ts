export interface SmsGroup extends AbstractEntity {
  type?: string;
  item?: EntityRef[];
}
