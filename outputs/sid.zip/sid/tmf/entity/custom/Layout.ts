export interface Layout {
  code?: string;
  title?: string;
  dataType?: string;
  ctlType?: string;
  unitCtlType?: string;
  unitExtraInfo?: any;
  extraInfo?: any;
  validateRules?: string[];
}
