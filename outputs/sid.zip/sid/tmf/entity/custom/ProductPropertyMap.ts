export interface ProductPropertyMap extends AbstractEntity {
  systemCode?: string;
  serviceCode?: string;
  quantity?: number;
  commitmentQuantity?: number;
  quantityUOM?: string;
  monthType?: string;
}
