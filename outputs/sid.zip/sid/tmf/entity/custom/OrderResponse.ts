export interface OrderResponse {
  status?: string;
  statusMessage?: string;
}
