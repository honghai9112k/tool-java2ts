export interface TaskDefinitionOda extends AbstractEntity {
  tenantId?: string;
  extendFields?: ExtendFields[];
  audit?: Audit;
  taskType?: string;
  taskDefinitionDFormInfos?: TaskDefinitionDFormInfo[];
  icon?: string;
}
