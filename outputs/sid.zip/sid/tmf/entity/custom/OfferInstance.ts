export interface OfferInstance extends AbstractEntity {
  status?: string;
  msisdn?: string;
  serviceId?: string;
  offerId?: number;
  productId?: number;
  createdDate?: Date;
  modifiedDate?: Date;
  daId?: string;
  identifyCode?: string;
  currentCycle?: number;
  totalCycle?: number;
}
