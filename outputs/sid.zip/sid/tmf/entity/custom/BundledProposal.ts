export interface BundledProposal extends EntityRef {
  bundledProposalOption?: BundledProposalOption;
}
