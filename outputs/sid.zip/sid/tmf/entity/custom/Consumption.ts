export interface Consumption extends AbstractEntity {
}
