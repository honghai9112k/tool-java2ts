export interface CriteriaSet extends AbstractEntity {
  criteria?: EntityRef[];
}
