export interface DataMatrix {
  label?: string;
  value?: string[];
}
