export interface TurtleExpression extends IntentExpression {
}
