export interface ConnectionSpecification extends AbstractEntity {
  endpointSpecification?: EntityRef[];
  associationType?: string;
}
