export interface CheckCredential_RES extends CheckCredential {
}
