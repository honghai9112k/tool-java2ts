export interface TroubleTicket_RES extends TroubleTicket {
}
