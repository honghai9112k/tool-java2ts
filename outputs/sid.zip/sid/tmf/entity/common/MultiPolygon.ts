export interface MultiPolygon {
  coordinates?: Polygon[];
}
