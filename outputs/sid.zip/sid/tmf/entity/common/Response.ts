export interface Response {
  code?: string;
  body?: string;
  statusCode?: string;
  header?: HeaderItem[];
}
