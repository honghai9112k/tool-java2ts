export interface TargetEntitySchema {
  code?: string;
  "@type"?: string;
  "@schemaLocation"?: string;
}
