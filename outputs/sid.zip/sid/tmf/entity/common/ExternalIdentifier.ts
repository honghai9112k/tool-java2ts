export interface ExternalIdentifier extends AbstractEntity {
  owner?: string;
  externalIdentifierType?: string;
  type?: string;
}
