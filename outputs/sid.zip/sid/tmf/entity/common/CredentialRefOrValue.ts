export interface CredentialRefOrValue extends EntityRefOrValue {
}
