export interface Milestone extends AbstractEntity {
  milestoneDate?: Date;
  message?: string;
  status?: string;
}
