export interface InteractionItem extends AbstractEntity {
  reason?: string;
  note?: Note[];
  item?: RelatedEntityRefOrValue;
  interactionItemRelationship?: InteractionItemRelationship[];
  itemDate?: TimePeriod;
  interactionItemType?: string;
  creationDate?: Date;
  relatedParty?: RelatedParty[];
  resolution?: string;
  attachment?: AttachmentRefOrValue[];
  relatedChannel?: RelatedChannel[];
}
