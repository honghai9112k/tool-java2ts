export interface GeographicSiteRefOrValue extends EntityRefOrValue {
}
