export interface SmsConfig extends AbstractEntity {
  key?: string;
  keyPart1?: string;
  keyPart2?: string;
  keyPart3?: string;
  keyPart4?: string;
  keyPart5?: string;
  targetType?: number;
  status?: number;
  order?: number;
  value?: string;
}
