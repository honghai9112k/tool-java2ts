export interface FeatureRelationship extends EntityRel {
}
