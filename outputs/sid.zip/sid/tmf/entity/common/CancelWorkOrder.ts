export interface CancelWorkOrder extends AbstractEntity {
  workOrder?: EntityRef;
  requestedCancellationDate?: Date;
  cancellationReason?: string;
  state?: string;
  effectiveCancellationDate?: Date;
}
