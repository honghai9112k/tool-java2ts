export interface IntentReportAttributeValueChange extends Event {
  event?: IntentReportAttributeValueChangePayload;
}
