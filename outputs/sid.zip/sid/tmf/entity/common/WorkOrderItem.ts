export interface WorkOrderItem extends AbstractEntity {
  note?: Note;
  product?: EntityRef;
  work?: WorkRefOrValue;
  itemTotalPrice?: OrderPrice[];
  relatedEntity?: RelatedEntity[];
  workOrderItemRelationship?: OrderItemRelationship[];
  appointment?: EntityRef;
  billingAccount?: EntityRef;
  productOrderItem?: EntityRef[];
  action?: string;
  itemPrice?: OrderPrice[];
  payment?: EntityRef[];
  state?: string;
  workOrderItem?: WorkOrderItem[];
}
