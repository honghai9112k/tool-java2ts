export interface MultiPoint {
  code?: string;
  type?: string;
  coordinates?: PositionArray;
}
