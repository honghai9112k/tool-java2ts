export interface Cdr extends AbstractEntity {
  cdrDate?: Date;
  status?: string;
  cdrType?: string;
  cdrCharacteristic?: CdrCharacteristic[];
  cdrDirectionType?: string;
  relatedParty?: RelatedParty;
  ratedCdr?: RatedCdr[];
  isBilled?: boolean;
  offerTariffType?: string;
  ratingAmountType?: string;
  amount?: Money;
  ratingDate?: Date;
  isTaxExempt?: boolean;
  productRef?: EntityRef;
  taxExcludedRatingAmount?: Money;
  taxIncludedRatingAmount?: Money;
  taxRate?: number;
}
