export interface PermissionSpecification extends AbstractEntity {
  action?: string;
  specificationCharacteristic?: CharacteristicSpecification[];
  function?: string;
}
