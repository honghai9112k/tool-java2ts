export interface GeographicAddress extends Place {
  country?: string;
  stateOrProvince?: string;
  provinceCode?: string;
  city?: string;
  cityCode?: string;
  locality?: string;
  localityCode?: string;
  streetName?: string;
  streetNr?: string;
  geographicAddressType?: string;
  children?: GeographicAddress[];
  geographicLocation?: GeographicLocationRefOrValue;
  geographicAddressRelationship?: GeographicAddressRelationship[];
  postcode?: string;
  streetType?: string;
  streetNrLast?: string;
  streetNrSuffix?: string;
  geographicSite?: GeographicSiteRefOrValue;
  countryCode?: StandardIdentifier[];
  streetNrLastSuffix?: string;
  streetSuffix?: string;
  geographicSubAddress?: GeographicSubAddress[];
}
