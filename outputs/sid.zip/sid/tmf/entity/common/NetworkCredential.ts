export interface NetworkCredential extends Credential {
}
