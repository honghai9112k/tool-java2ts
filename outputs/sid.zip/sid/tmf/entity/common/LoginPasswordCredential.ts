export interface LoginPasswordCredential extends Credential {
}
