export interface Entitlement {
  action?: string;
  function?: string;
  "@baseType"?: string;
  "@schemaLocation"?: string;
  "@type"?: string;
}
