export interface BiometricCredential extends Credential {
}
