export interface WorkRelationship extends EntityRel {
  code?: string;
  work?: WorkRefOrValue;
  workRelationshipCharacteristic?: Characteristic[];
}
