export interface AvailabilityCheck extends TaskResource {
  capacityOption?: Capacity[];
}
