export interface RelatedPlaceRefOrValue extends AbstractEntity {
  role?: string;
  place?: PlaceRefOrValue;
}
