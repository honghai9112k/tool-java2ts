export interface Reservation extends AbstractEntity {
  cancellationDate?: string;
  cancellationReason?: string;
  completionDate?: string;
  creationDate?: Date;
  expectedCompletionDate?: string;
  requestedCompletionDate?: string;
  requestedStartDate?: string;
  stateChangeDate?: Date;
  stateChangeReason?: string;
  channel?: EntityRef;
  relatedEntity?: RelatedEntity[];
  relatedParty?: RelatedParty[];
  reservationPeriod?: TimePeriod;
  state?: string;
}
