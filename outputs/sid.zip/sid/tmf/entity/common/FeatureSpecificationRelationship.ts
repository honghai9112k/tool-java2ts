export interface FeatureSpecificationRelationship extends EntityRel {
  parentSpecificationHref?: string;
  featureId?: string;
  parentSpecificationId?: string;
}
