export interface TroubleTicketResolvedEvent extends Event {
  troubleTicketResolvedEventPayload?: TroubleTicketResolvedEventPayload;
}
