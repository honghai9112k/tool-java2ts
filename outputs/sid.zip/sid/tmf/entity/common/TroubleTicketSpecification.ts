export interface TroubleTicketSpecification extends AbstractEntity {
  specCharacteristic?: CharacteristicSpecification[];
  relatedParty?: RelatedParty[];
  creationDate?: Date;
}
