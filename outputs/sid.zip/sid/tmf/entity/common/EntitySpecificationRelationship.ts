export interface EntitySpecificationRelationship extends EntityRel {
  associationSpec?: EntityRef;
}
