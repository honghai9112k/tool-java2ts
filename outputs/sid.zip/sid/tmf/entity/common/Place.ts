export interface Place extends AbstractEntity {
}
