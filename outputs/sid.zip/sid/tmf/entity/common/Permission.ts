export interface Permission extends AbstractEntity {
  permissionSpecificationSet?: PermissionSpecificationSetRef;
  managedAssetGroup?: AssetGroup;
  permissionSpecification?: PermissionSpecificationRefOrValue;
  characteristic?: Characteristic[];
}
