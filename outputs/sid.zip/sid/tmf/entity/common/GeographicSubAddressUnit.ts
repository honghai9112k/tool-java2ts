export interface GeographicSubAddressUnit extends AbstractEntity {
  subUnitNumber?: string;
  subUnitType?: string;
}
