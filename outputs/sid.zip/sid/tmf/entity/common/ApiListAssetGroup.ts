export interface ApiListAssetGroup extends AssetGroup {
}
