export interface ExternalReference extends AbstractEntity {
  externalReferenceType?: string;
}
