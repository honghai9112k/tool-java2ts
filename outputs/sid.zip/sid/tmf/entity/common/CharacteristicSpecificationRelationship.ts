export interface CharacteristicSpecificationRelationship extends EntityRel {
  characteristicSpecificationId?: string;
  parentSpecificationHref?: string;
  parentSpecificationId?: string;
}
