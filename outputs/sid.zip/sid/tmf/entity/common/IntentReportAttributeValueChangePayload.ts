export interface IntentReportAttributeValueChangePayload {
  intentReport?: IntentReport;
}
