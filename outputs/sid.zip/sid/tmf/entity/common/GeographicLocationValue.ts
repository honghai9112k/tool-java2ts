export interface GeographicLocationValue extends AbstractEntity {
  bbox?: number[];
}
