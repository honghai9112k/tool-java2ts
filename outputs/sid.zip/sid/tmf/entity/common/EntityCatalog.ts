export interface EntityCatalog extends AbstractEntity {
  category?: EntityRef[];
  relatedParty?: RelatedParty[];
  importJob?: ImportJob;
  exportJob?: ExportJob;
}
