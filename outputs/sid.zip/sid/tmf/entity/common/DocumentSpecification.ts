export interface DocumentSpecification extends AbstractEntity {
}
