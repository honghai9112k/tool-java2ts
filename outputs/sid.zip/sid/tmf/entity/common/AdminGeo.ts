export interface AdminGeo extends AbstractEntity {
  level?: number;
  children?: Ward[];
}
