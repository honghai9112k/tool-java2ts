export interface Reference extends AbstractEntity {
}
