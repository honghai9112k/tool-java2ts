export interface IntentSpecification extends EntitySpecification {
  expressionSpecification?: ExpressionSpecification;
  intentSpecRelationship?: IntentSpecificationRelationship[];
}
