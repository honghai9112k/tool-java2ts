export interface EndpointRef extends EntityRef {
  isRoot?: boolean;
  connectionPoint?: ConnectionPointRef;
}
