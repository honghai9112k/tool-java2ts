export interface CapacitySpecification extends AbstractEntity {
  externalIdentifier?: ExternalIdentifier[];
  capacityCharacteristicSpecification?: CharacteristicSpecification[];
  relatedCapacitySpecification?: CapacitySpecification[];
}
