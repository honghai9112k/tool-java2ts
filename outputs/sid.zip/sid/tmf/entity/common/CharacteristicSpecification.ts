export interface CharacteristicSpecification extends AbstractEntity {
  valueType?: string;
  pickList?: string;
  configurable?: boolean;
  minCardinality?: number;
  maxCardinality?: number;
  isUnique?: boolean;
  extensible?: boolean;
  regex?: string;
  characteristicValueSpecification?: CharacteristicValueSpecification[];
  layout?: Layout;
  characteristicCatalog?: EntityRef;
  "@valueSchemaLocation"?: string;
  charSpecRelationship?: CharacteristicSpecificationRelationship[];
  value?: any;
  unitOfMeasure?: string;
  isTemplate?: boolean;
  productSpecification?: EntityRef;
  characteristicValueSpecificationUsed?: CharacteristicValueSpecification;
}
