export interface GeographicSiteFeature extends Feature {
  note?: Note[];
  attachment?: AttachmentRefOrValue[];
  relatedParty?: RelatedParty[];
  featureCategory?: string[];
}
