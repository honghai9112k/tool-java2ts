export interface Comment extends AbstractEntity {
  comment?: string;
  systemId?: string;
  time?: Date;
}
