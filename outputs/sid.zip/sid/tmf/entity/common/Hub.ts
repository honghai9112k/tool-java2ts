export interface Hub extends AbstractEntity {
  callback?: string;
  query?: string;
}
