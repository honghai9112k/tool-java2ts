export interface Credential extends AbstractEntity {
  state?: string;
  trustLevel?: string;
  creationDate?: Date;
  relatedContactMedium?: RelatedContactMedium[];
  digitalIdentity?: EntityRef;
  login?: string;
  tokenCredential?: string;
  password?: string;
  securityKeyId?: string;
  securityKeyType?: string;
  securityKeyProvider?: string;
  biometricType?: string;
  attachment?: AttachmentRefOrValue[];
  biometricSubType?: string;
  resource?: EntityRef;
}
