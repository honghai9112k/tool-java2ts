export interface GeographicAddressRelationship extends EntityRel {
}
