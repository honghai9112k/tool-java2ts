export interface AssociationSpecification extends AbstractEntity {
  constraint?: EntityRef[];
  associationRoleSpec?: AssociationRoleSpecification[];
}
