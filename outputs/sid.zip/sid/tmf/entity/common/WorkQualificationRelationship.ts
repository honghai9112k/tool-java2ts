export interface WorkQualificationRelationship extends EntityRel {
  code?: string;
}
