export interface AssetGroup extends AbstractEntity {
  entityType?: any;
  entity?: EntityRef[];
  filter?: string;
  apiProduct?: EntityRef[];
}
