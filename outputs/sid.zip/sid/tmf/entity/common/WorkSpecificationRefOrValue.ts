export interface WorkSpecificationRefOrValue extends EntityRefOrValue {
}
