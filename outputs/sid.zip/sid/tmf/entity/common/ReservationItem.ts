export interface ReservationItem extends AbstractEntity {
  quantity?: number;
  stateChangeDate?: Date;
  stateChangeReason?: string;
  action?: string;
  appliedCapacity?: Capacity;
  capacityDemand?: Capacity;
  relatedEntity?: RelatedEntity[];
  relatedParty?: RelatedParty[];
  reservationPeriod?: TimePeriod;
  state?: string;
}
