export interface Expression extends AbstractEntity {
  expressionLanguage?: string;
  expressionValue?: string;
  iri?: string;
}
