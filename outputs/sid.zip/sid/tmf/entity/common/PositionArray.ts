export interface PositionArray {
  code?: string;
  positions?: Position[];
}
