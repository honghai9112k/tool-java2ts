export interface GeographicSite extends Place {
  calendar?: CalendarPeriod[];
  siteFeature?: GeographicSiteFeature[];
  contactMedium?: ContactMedium[];
  externalIdentifier?: ExternalIdentifier[];
  siteRelationship?: GeographicSiteRelationship[];
  place?: PlaceRefOrValue[];
  siteCategory?: string;
  creationDate?: Date;
  relatedParty?: RelatedParty[];
  status?: string;
}
