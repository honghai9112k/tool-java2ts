export interface ExportJob extends AbstractEntity {
  completionDate?: Date;
  contentType?: string;
  creationDate?: Date;
  errorLog?: string;
  path?: string;
  query?: string;
  status?: string;
  url?: string;
}
