export interface ApplicableTimePeriod {
  dayOfWeek?: string;
  rangeInterval?: string;
  fromToDateTime?: TimePeriod;
}
