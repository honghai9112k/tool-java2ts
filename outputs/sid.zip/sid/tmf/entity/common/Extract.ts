export interface Extract extends TaskResource {
  capacityDemand?: Capacity;
  extractedResource?: EntityRef[];
}
