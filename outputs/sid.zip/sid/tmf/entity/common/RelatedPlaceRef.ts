export interface RelatedPlaceRef extends EntityRef {
  role?: string;
  place?: EntityRef;
}
