export interface Intent extends AbstractEntity {
  isBundle?: boolean;
  intentSpecification?: EntityRef;
  intentRelationship?: EntityRelationship[];
  expression?: IntentExpression;
  priority?: string;
  relatedParty?: RelatedParty[];
  creationDate?: Date;
  characteristic?: Characteristic[];
  statusChangeDate?: Date;
  attachment?: AttachmentRefOrValue[];
  context?: string;
  intentReport?: IntentReport[];
}
