export interface AttachmentRef extends EntityRef {
  attachmentType?: string;
  value?: string;
}
