export interface GeographicAddressContactMedium extends ContactMedium {
}
