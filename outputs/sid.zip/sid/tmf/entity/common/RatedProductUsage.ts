export interface RatedProductUsage {
  bucketValueConvertedInAmount?: Money;
  isBilled?: boolean;
  offerTariffType?: string;
  ratingAmountType?: string;
  ratingDate?: Date;
  usageRatingTag?: string;
  isTaxExempt?: boolean;
  taxExcludedRatingAmount?: Money;
  taxIncludedRatingAmount?: Money;
  taxRate?: number;
}
