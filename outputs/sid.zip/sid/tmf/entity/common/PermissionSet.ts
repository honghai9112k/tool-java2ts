export interface PermissionSet extends AbstractEntity {
  permissionSetSpecification?: EntityRef;
  permission?: Permission[];
  creationDate?: Date;
  user?: RelatedParty;
  granter?: RelatedParty;
}
