export interface SetAssetGroup extends AssetGroup {
}
