export interface Heal extends AbstractEntity {
  cause?: string;
  degreeOfHealing?: string;
  healAction?: string;
  startTime?: string;
  additionalParms?: Characteristic[];
  healPolicy?: EntityRef;
  resourceFunction?: ResourceFunction;
  state?: string;
}
