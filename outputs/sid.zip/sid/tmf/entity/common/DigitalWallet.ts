export interface DigitalWallet extends PaymentMethod {
}
