export interface CdrCharacteristic extends Characteristic {
}
