export interface InteractionRelationship extends EntityRel {
  code?: string;
}
