export interface GeographicAddressValidation extends AbstractEntity {
  validationResult?: string;
  alternateGeographicAddress?: AlternateGeographicAddressValidation[];
  validGeographicAddress?: GeographicAddress;
  provideAlternative?: boolean;
  submittedGeographicAddress?: GeographicAddress;
  state?: string;
  validationDate?: Date;
}
