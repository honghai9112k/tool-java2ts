export interface TroubleTicketRelationship extends EntityRel {
}
