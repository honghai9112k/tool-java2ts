export interface WorkforceEmployeeAssignment extends AbstractEntity {
  skillType?: string;
  state?: string;
  timeSlot?: TimeSlot[];
  workforceEmployee?: PartyRefOrValue;
}
