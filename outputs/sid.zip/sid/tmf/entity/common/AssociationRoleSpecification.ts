export interface AssociationRoleSpecification extends AbstractEntity {
  aggregation?: string;
  defaultQuantity?: number;
  entityType?: string;
  isNavigable?: boolean;
  isSource?: boolean;
  maxQuantity?: number;
  minQuantity?: number;
  role?: string;
}
