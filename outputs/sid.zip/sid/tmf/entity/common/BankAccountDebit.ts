export interface BankAccountDebit extends PaymentMethod {
}
