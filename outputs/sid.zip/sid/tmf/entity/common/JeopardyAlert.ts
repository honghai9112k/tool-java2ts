export interface JeopardyAlert extends AbstractEntity {
  exception?: string;
  jeopardyType?: string;
  message?: string;
  alertDate?: Date;
}
