export interface EntityCategory extends AbstractEntity {
  isRoot?: boolean;
  parentId?: string;
  childCategory?: EntityRef[];
  entityCatalogItem?: EntityRef[];
}
