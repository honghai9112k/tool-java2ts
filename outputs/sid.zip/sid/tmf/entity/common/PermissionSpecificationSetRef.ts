export interface PermissionSpecificationSetRef extends EntityRef {
}
