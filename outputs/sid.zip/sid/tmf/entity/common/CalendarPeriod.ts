export interface CalendarPeriod extends AbstractEntity {
  timeZone?: string;
  day?: string;
  hourPeriod?: HourPeriod[];
  status?: string;
}
