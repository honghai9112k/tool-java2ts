export interface CheckPermission extends AbstractEntity {
  state?: string;
  permissionSpecification?: PermissionSpecificationRefOrValue;
  user?: RelatedParty;
  characteristic?: Characteristic[];
  entity?: EntityRefOrValue[];
}
