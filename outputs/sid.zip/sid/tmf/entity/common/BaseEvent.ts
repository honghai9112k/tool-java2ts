export interface BaseEvent extends AbstractEntity {
  eventId?: string;
  domain?: string;
  eventTime?: Date;
  correlationId?: string;
  eventType?: string;
  event?: string;
  title?: string;
  priority?: string;
  timeOcurred?: Date;
}
