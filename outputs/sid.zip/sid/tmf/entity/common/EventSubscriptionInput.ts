export interface EventSubscriptionInput {
  callback?: string;
  query?: string;
}
