export interface AssociationRole extends AbstractEntity {
  isSource?: boolean;
  role?: string;
  entity?: EntityRef;
}
