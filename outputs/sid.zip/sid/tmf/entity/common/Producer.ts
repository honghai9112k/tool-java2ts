export interface Producer extends PartyRole {
}
