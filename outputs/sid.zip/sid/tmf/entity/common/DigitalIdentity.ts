export interface DigitalIdentity extends AbstractEntity {
  relatedSecurityPrincipal?: EntityRef[];
  resourceIdentified?: EntityRef;
  creationDate?: Date;
  individualIdentified?: EntityRef;
  partyRoleIdentified?: EntityRef[];
  credential?: CredentialRefOrValue[];
  attachment?: AttachmentRefOrValue[];
  nickname?: string;
  resourceRoleIdentified?: EntityRef[];
  state?: string;
  relatedContactMedium?: RelatedContactMedium[];
}
