export interface CheckWorkQualificationItem extends AbstractEntity {
  expectedWorkDate?: Date;
  expirationDate?: Date;
  qualificationResult?: string;
  state?: string;
  alternateWorkProposal?: AlternateWorkProposal[];
  eligibilityUnavailabilityReason?: EligibilityUnavailabilityReason[];
  qualificationItemRelationship?: WorkQualificationItemRelationship[];
  qualificationRelationship?: WorkQualificationRelationship[];
  terminationError?: TerminationError[];
  work?: WorkRefOrValue;
}
