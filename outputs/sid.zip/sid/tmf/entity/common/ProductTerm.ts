export interface ProductTerm extends AbstractEntity {
  duration?: Duration;
}
