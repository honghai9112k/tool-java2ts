export interface Push extends TaskResource {
  pushedResource?: EntityRef[];
}
