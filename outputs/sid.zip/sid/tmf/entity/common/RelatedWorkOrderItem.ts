export interface RelatedWorkOrderItem extends AbstractEntity {
  orderItemAction?: string;
  orderItemId?: string;
  role?: string;
  workOrderHref?: string;
  workOrderId?: string;
}
