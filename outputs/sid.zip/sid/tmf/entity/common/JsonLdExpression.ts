export interface JsonLdExpression extends AbstractEntity {
}
