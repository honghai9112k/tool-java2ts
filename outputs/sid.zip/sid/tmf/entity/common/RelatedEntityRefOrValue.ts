export interface RelatedEntityRefOrValue extends AbstractEntity {
  entity?: EntityRefOrValue;
  role?: string;
}
