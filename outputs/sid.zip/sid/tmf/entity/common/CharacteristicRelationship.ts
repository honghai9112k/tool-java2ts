export interface CharacteristicRelationship extends EntityRel {
  code?: string;
}
