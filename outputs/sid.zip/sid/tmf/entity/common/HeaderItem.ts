export interface HeaderItem {
  code?: string;
  name?: string;
  value?: string;
}
