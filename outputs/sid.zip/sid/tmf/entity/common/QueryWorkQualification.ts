export interface QueryWorkQualification extends AbstractEntity {
  effectiveQualificationDate?: Date;
  estimatedResponseDate?: Date;
  expectedQualificationDate?: Date;
  expirationDate?: Date;
  externalId?: string;
  instantSyncQualification?: boolean;
  queryWorkQualificationDate?: Date;
  place?: PlaceRefOrValue;
  relatedParty?: RelatedParty[];
  searchCriteria?: WorkQualificationItem;
  state?: string;
  workQualificationItem?: WorkQualificationItem[];
}
