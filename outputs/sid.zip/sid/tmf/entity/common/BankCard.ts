export interface BankCard extends PaymentMethod {
}
