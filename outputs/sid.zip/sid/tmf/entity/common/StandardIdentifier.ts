export interface StandardIdentifier extends AbstractEntity {
  format?: string;
  value?: string;
}
