export interface PermissionSpecificationSet extends AbstractEntity {
  involvementRole?: string;
  permissionSpecification?: PermissionSpecificationRefOrValue[];
}
