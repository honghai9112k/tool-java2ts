export interface WorkQualification extends AbstractEntity {
  effectiveQualificationDate?: Date;
  estimatedResponseDate?: Date;
  expectedQualificationDate?: Date;
  expirationDate?: Date;
  externalId?: string;
  instantSyncQualification?: boolean;
  place?: PlaceRefOrValue;
  relatedParty?: RelatedParty[];
  state?: string;
}
