export interface CheckCredential extends AbstractEntity {
  credential?: Credential;
  creationDate?: Date;
  status?: string;
}
