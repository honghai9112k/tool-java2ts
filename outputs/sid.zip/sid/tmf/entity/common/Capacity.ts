export interface Capacity extends AbstractEntity {
  place?: PlaceRefOrValue;
  capacitySpecification?: EntityRef;
  rangeInterval?: string;
  capacityStatus?: string;
  applicableTimePeriod?: ApplicableTimePeriod[];
  relatedCapacity?: Capacity[];
  capacityAmountTo?: Quantity;
  capacityCharacteristic?: Characteristic[];
  capacityAmount?: Quantity;
  capacityAmountFrom?: Quantity;
  plannedOrActualCapacity?: string;
  capacitySpec?: EntityRef;
}
