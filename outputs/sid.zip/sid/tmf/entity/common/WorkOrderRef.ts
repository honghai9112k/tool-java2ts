export interface WorkOrderRef extends EntityRef {
  description?: string;
  priority?: string;
  state?: string;
  requestedStartDate?: Date;
  requestedCompletionDate?: Date;
}
