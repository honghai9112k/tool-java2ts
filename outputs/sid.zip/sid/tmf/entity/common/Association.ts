export interface Association extends AbstractEntity {
  associationSpec?: EntityRef;
  associationRole?: AssociationRole[];
  constraint?: EntityRef[];
}
