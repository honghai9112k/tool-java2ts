export interface PermissionSpecificationRefOrValue extends EntityRefOrValue {
}
