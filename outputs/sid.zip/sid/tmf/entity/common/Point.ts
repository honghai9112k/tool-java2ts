export interface Point {
  type?: string;
  coordinates?: Position;
}
