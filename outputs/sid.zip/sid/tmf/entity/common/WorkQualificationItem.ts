export interface WorkQualificationItem extends AbstractEntity {
  expectedWorkDate?: Date;
  expirationDate?: Date;
  eligibilityUnavailabilityReason?: EligibilityUnavailabilityReason[];
  work?: WorkRefOrValue;
}
