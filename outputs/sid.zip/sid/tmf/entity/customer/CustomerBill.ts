export interface CustomerBill extends AbstractEntity {
  billDocument?: DocumentRefOrValue[];
  taxExcludedAmount?: Money;
  billingPeriod?: TimePeriod;
  runType?: string;
  taxItem?: TaxItem[];
  financialAccount?: EntityRef;
  billDate?: Date;
  billingAccount?: EntityRef;
  relatedParty?: RelatedParty[];
  amountDue?: Money;
  appliedPayment?: AppliedPayment[];
  nextBillDate?: Date;
  paymentDueDate?: Date;
  remainingAmount?: Money;
  paymentMethod?: EntityRef;
  state?: string;
  category?: string;
  billNo?: string;
  billCycle?: EntityRef;
  taxIncludedAmount?: Money;
}
