export interface ProductOrderItem extends AbstractEntity {
  note?: Note[];
  product?: ProductRefOrValue;
  quantity?: number;
  productOffering?: EntityRef;
  itemTotalPrice?: OrderPrice[];
  appointment?: EntityRef;
  billingAccount?: EntityRef;
  productOrderItem?: ProductOrderItem[];
  productOrderItemRelationship?: OrderItemRelationship[];
  itemTerm?: OrderTerm[];
  qualification?: EntityRef[];
  productOfferingQualificationItem?: EntityRef;
  action?: string;
  quoteItem?: EntityRef;
  itemPrice?: OrderPrice[];
  payment?: EntityRef[];
  state?: string;
}
