export interface QuoteItem extends AbstractEntity {
  note?: Note[];
  product?: Product;
  quantity?: number;
  productOffering?: EntityRef;
  quoteItemAuthorization?: Authorization[];
  appointment?: EntityRef[];
  relatedParty?: RelatedParty[];
  productOfferingQualificationItem?: EntityRef;
  attachment?: AttachmentRefOrValue[];
  action?: string;
  quoteItem?: QuoteItem[];
  state?: string;
  quoteItemPrice?: QuotePrice[];
  quoteItemRelationship?: QuoteItemRelationship[];
}
