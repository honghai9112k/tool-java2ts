export interface Customer360PaymentMethodVO extends AbstractEntity {
  isPreferred?: boolean;
  status?: string;
}
