export interface Customer360 extends AbstractEntity {
  serviceProblem?: Customer360ServiceProblemVO[];
  product?: Customer360ProductVO[];
  agreement?: Customer360AgreementVO[];
  customerBill?: Customer360CustomerBillVO[];
  productOrder?: Customer360ProductOrderVO[];
  recommendation?: Customer360RecommendationVO[];
  appointment?: Customer360AppointmentVO[];
  troubleTicket?: Customer360TroubleTicketVO[];
  partyInteraction?: Customer360PartyInteractionVO[];
  quote?: Customer360QuoteVO[];
  paymentMethod?: Customer360PaymentMethodVO[];
  account?: Customer360AccountVO[];
  customer?: Customer360CustomerVO;
  loyaltyAccount?: Customer360LoyaltyAccountVO[];
  promotion?: Customer360PromotionVO[];
}
