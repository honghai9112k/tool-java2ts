export interface TimeSlot extends AbstractEntity {
  relatedParty?: RelatedParty;
}
