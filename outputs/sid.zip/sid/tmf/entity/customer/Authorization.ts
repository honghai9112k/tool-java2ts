export interface Authorization extends AbstractEntity {
  givenDate?: Date;
  approver?: RelatedParty[];
  signatureRepresentation?: string;
  requestedDate?: Date;
  state?: string;
}
