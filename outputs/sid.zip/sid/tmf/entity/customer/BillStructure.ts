export interface BillStructure extends AbstractEntity {
  presentationMedia?: BillPresentationMediaRefOrValue[];
  format?: BillFormatRefOrValue;
  cycleSpecification?: BillingCycleSpecificationRefOrValue;
}
