export interface Customer360PromotionVO extends AbstractEntity {
  type?: string;
}
