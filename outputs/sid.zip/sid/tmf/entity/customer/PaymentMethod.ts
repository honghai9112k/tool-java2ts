export interface PaymentMethod extends AbstractEntity {
  isPreferred?: boolean;
  status?: string;
  statusDate?: Date;
  account?: EntityRef[];
  relatedParty?: RelatedParty;
  relatedPlace?: RelatedPlace;
}
