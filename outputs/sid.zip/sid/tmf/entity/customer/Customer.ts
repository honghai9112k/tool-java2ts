export interface Customer extends PartyRole {
  msisdn?: string;
}
