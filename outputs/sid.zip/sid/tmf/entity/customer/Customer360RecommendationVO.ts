export interface Customer360RecommendationVO extends AbstractEntity {
  recommendationType?: string;
  category?: EntityRef;
}
