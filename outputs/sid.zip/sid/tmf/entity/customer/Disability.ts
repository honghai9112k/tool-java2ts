export interface Disability {
  code?: string;
  disabilityCode?: string;
  disabilityName?: string;
  validFor?: TimePeriod;
}
