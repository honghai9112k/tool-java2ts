export interface PaymentMethodRefOrValue extends EntityRefOrValue {
}
