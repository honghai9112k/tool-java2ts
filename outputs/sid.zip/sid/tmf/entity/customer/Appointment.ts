export interface Appointment extends AbstractEntity {
  category?: string;
  creationDate?: Date;
  externalId?: string;
  attachment?: AttachmentRefOrValue[];
  calendarEvent?: EntityRef;
  contactMedium?: ContactMedium[];
  note?: Note[];
  relatedEntity?: RelatedEntity[];
  relatedParty?: RelatedParty[];
  relatedPlace?: RelatedPlaceRefOrValue;
  status?: string;
}
