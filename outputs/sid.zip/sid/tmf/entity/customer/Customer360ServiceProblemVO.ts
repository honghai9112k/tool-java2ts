export interface Customer360ServiceProblemVO extends AbstractEntity {
  category?: string;
  priority?: number;
  originatingSystem?: string;
  affectedService?: EntityRef[];
  status?: string;
}
