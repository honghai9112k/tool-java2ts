export interface Customer360LoyaltyAccountVO extends AbstractEntity {
  accountBalance?: LoyaltyAccountBalance[];
  state?: string;
}
