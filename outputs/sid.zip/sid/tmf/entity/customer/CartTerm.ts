export interface CartTerm extends AbstractEntity {
  duration?: Duration;
}
