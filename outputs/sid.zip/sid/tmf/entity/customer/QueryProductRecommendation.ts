export interface QueryProductRecommendation extends AbstractEntity {
  instantSyncRecommendation?: boolean;
  recommendationType?: string;
  category?: EntityRef[];
  channel?: EntityRef[];
  place?: EntityRef;
  productOrder?: EntityRef[];
  productOrderItem?: EntityRef[];
  recommendationItem?: RecommendationItem[];
  relatedParty?: RelatedParty;
  shoppingCart?: EntityRef[];
  shoppingCartItem?: EntityRef[];
  state?: string;
}
