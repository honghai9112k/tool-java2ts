export interface CustomerBillOnDemand extends AbstractEntity {
  customerBill?: EntityRef;
  state?: string;
  billingAccount?: EntityRef;
  relatedParty?: RelatedParty;
}
