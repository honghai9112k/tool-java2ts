export interface AppliedBillingTaxRate extends AbstractEntity {
  taxAmount?: Money;
  taxRate?: number;
  taxCategory?: string;
}
