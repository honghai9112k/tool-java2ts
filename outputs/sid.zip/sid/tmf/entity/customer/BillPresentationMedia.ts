export interface BillPresentationMedia extends AbstractEntity {
}
