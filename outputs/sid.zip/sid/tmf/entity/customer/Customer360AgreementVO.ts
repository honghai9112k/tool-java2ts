export interface Customer360AgreementVO extends AbstractEntity {
  agreementPeriod?: TimePeriod;
  agreementType?: string;
  agreementSpecification?: EntityRef;
  status?: string;
}
