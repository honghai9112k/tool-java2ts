export interface Customer360AccountVO extends AbstractEntity {
  state?: string;
  accountType?: string;
}
