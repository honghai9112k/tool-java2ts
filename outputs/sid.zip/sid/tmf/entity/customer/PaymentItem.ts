export interface PaymentItem extends AbstractEntity {
  amount?: Money;
  item?: EntityRef;
  taxAmount?: Money;
  totalAmount?: Money;
}
