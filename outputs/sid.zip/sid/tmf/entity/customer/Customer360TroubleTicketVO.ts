export interface Customer360TroubleTicketVO extends AbstractEntity {
  severity?: string;
  statusChangeReason?: string;
  ticketType?: string;
  creationDate?: Date;
  priority?: string;
  statusChangeDate?: Date;
  expectedResolutionDate?: Date;
  externalIdentifier?: string;
  requestedResolutionDate?: Date;
  status?: string;
}
