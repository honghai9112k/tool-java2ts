export interface BillPresentationMediaRefOrValue extends EntityRefOrValue {
}
