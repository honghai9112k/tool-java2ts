export interface Customer360AppointmentVO extends AbstractEntity {
  calendarEvent?: EntityRef;
  externalId?: string;
  category?: string;
  creationDate?: Date;
  status?: string;
}
