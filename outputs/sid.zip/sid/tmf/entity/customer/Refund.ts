export interface Refund extends AbstractEntity {
  authorizationCode?: string;
  correlatorId?: string;
  refundDate?: Date;
  status?: string;
  statusDate?: Date;
  account?: EntityRef;
  amount?: Money;
  channel?: EntityRef;
  payment?: EntityRef;
  paymentMethod?: PaymentMethod;
  requestor?: RelatedParty;
  taxAmount?: Money;
  totalAmount?: Money;
}
