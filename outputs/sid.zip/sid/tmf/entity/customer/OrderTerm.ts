export interface OrderTerm extends AbstractEntity {
  duration?: Duration;
}
