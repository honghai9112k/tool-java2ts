export interface SearchTimeSlot extends AbstractEntity {
  searchDate?: Date;
  searchResult?: string;
  availableTimeSlot?: TimeSlot[];
  relatedEntity?: RelatedEntity[];
  relatedParty?: RelatedParty;
  relatedPlace?: RelatedPlaceRefOrValue;
  requestedTimeSlot?: TimeSlot[];
  status?: string;
}
