export interface Customer360ProductVO extends AbstractEntity {
  productOffering?: EntityRef;
  status?: string;
}
