export interface IndividualIdentification extends AbstractEntity {
  issuingAuthority?: string;
  identificationType?: string;
  attachment?: AttachmentRefOrValue;
  issuingDate?: Date;
  identificationId?: string;
}
