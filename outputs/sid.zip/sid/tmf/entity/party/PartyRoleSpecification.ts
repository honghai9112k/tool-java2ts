export interface PartyRoleSpecification extends EntitySpecification {
  permissionSpecificationSet?: EntityRef[];
  agreementSpecification?: EntityRef[];
  status?: string;
}
