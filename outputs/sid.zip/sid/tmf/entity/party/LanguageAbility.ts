export interface LanguageAbility {
  code?: string;
  languageCode?: string;
  languageName?: string;
  isFavouriteLanguage?: boolean;
  writingProficiency?: string;
  readingProficiency?: string;
  speakingProficiency?: string;
  listeningProficiency?: string;
  validFor?: TimePeriod;
}
