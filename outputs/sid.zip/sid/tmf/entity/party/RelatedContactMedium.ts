export interface RelatedContactMedium extends AbstractEntity {
  relationDate?: Date;
  contactMedium?: ContactMedium;
  role?: string;
}
