export interface PartyRevSharingReportItem extends AbstractEntity {
  sharingReportItemIDetail?: PartyRevSharingReportItemDetail[];
  partyRevSharingModelItem?: EntityRef;
  bill?: EntityRef;
  relatedParty?: RelatedParty;
  cdrTransactionItem?: EntityRef;
  money?: Money;
  partyAccount?: EntityRef;
  payment?: EntityRef;
  billPeriod?: TimePeriod;
  status?: string;
  createDate?: Date;
}
