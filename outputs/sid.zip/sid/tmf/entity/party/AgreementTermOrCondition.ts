export interface AgreementTermOrCondition extends AbstractEntity {
  termType?: number;
  commitmentAmount?: Quantity;
  commitmentDuration?: TimePeriod;
  commitmentMoney?: Money;
  obligationPeriod?: string;
  penaltyType?: number;
  penaltyAmount?: Money;
  penaltyFormula?: string;
  graceDuration?: TimePeriod;
}
