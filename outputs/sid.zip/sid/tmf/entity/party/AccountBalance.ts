export interface AccountBalance extends AbstractEntity {
  amount?: Money;
  balanceType?: string;
}
