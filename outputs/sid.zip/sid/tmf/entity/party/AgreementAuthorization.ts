export interface AgreementAuthorization extends AbstractEntity {
  date?: Date;
  signatureRepresentation?: string;
  state?: string;
  signature?: Attachment;
  party?: EntityRef;
}
