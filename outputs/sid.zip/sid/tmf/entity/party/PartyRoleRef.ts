export interface PartyRoleRef extends EntityRef {
  partyId?: string;
  partyName?: string;
}
