export interface Contact extends AbstractEntity {
  contactMedium?: ContactMedium[];
  contactName?: string;
  partyRoleType?: string;
  contactType?: string;
  relatedParty?: RelatedParty;
}
