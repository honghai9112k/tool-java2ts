export interface PartyRefOrValue extends EntityRefOrValue {
}
