export interface PartyRevSharingAlgorithm extends AbstractEntity {
  actionVariable?: PartyRevSharingPolicyActionVariable[];
  conditionVariable?: PartyRevSharingPolicyConditionVariable[];
  policy?: EntityRef[];
}
