export interface OtherNameOrganization extends AbstractEntity {
  tradingName?: string;
  nameType?: string;
}
