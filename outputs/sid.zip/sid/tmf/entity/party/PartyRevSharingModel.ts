export interface PartyRevSharingModel extends AbstractEntity {
  partyRevSharingModelItem?: PartyRevSharingModelItem[];
  productSpecification?: EntityRef[];
  relatedParty?: RelatedParty[];
}
