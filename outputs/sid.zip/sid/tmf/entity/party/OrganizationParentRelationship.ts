export interface OrganizationParentRelationship extends EntityRel {
  code?: string;
  organization?: EntityRef;
}
