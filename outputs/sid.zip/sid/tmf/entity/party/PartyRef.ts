export interface PartyRef extends EntityRef {
}
