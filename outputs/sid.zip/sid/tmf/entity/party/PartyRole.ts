export interface PartyRole extends AbstractEntity {
  contactMedium?: ContactMedium[];
  creditProfile?: CreditProfile[];
  role?: string;
  agreement?: EntityRef[];
  relatedParty?: RelatedParty[];
  characteristic?: Characteristic[];
  statusReason?: string;
  partyRoleSpecification?: EntityRef;
  paymentMethod?: EntityRef[];
  engagedParty?: EntityRef;
  account?: EntityRef[];
  status?: string;
}
