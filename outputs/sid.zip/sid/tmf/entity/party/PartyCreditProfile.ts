export interface PartyCreditProfile extends AbstractEntity {
  creditAgencyName?: string;
  creditAgencyType?: string;
  ratingReference?: string;
  ratingScore?: number;
}
