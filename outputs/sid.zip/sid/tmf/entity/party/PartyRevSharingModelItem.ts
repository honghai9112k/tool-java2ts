export interface PartyRevSharingModelItem extends AbstractEntity {
  agreement?: EntityRef[];
  partyAccount?: EntityRef;
  sharingModelItemInvolvement?: PartyRevSharingModelItemInvolvement[];
  relatedParty?: RelatedParty;
}
