export interface RelatedParty extends EntityRef {
  role?: string;
  contact?: ContactMedium[];
  partyOrPartyRole?: EntityRef;
}
