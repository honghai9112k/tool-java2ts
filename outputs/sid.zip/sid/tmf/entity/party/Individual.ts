export interface Individual extends Party {
  gender?: string;
  aristocraticTitle?: string;
  disability?: Disability[];
  formattedName?: string;
  individualIdentification?: IndividualIdentification[];
  title?: string;
  legalName?: string;
  countryOfBirth?: string;
  skill?: Skill[];
  familyName?: string;
  deathDate?: Date;
  generation?: string;
  placeOfBirth?: string;
  givenName?: string;
  birthDate?: Date;
  languageAbility?: LanguageAbility[];
  nationality?: string;
  preferredGivenName?: string;
  familyNamePrefix?: string;
  middleName?: string;
  location?: string;
  otherName?: OtherNameIndividual[];
  maritalStatus?: string;
  status?: string;
}
