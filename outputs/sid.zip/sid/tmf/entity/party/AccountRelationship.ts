export interface AccountRelationship extends EntityRel {
  code?: string;
  account?: EntityRef;
}
