export interface PartyAccount extends Account {
  defaultPaymentMethod?: EntityRef;
  financialAccount?: FinancialAccount;
  paymentPlan?: PaymentPlan[];
  paymentStatus?: string;
  billStructure?: BillStructure;
}
