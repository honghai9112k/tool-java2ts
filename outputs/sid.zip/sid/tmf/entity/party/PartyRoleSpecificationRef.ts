export interface PartyRoleSpecificationRef extends EntityRef {
}
