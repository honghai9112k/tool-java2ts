export interface EmailContactMedium extends ContactMedium {
}
