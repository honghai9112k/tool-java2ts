export interface OtherNameIndividual {
  code?: string;
  title?: string;
  aristocraticTitle?: string;
  generation?: string;
  givenName?: string;
  preferredGivenName?: string;
  familyNamePrefix?: string;
  familyName?: string;
  legalName?: string;
  middleName?: string;
  fullName?: string;
  formattedName?: string;
  validFor?: TimePeriod;
}
