export interface PartyRevSharingModelInvolPrice extends AbstractEntity {
  productOfferingPrice?: EntityRef;
  partyRevSharingAlgorithm?: EntityRef[];
}
