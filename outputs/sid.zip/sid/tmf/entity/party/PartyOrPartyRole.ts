export interface PartyOrPartyRole extends EntityOrOtherEntity {
  party?: Party;
  partyRole?: PartyRole;
}
