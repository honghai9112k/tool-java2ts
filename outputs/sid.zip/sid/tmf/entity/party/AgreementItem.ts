export interface AgreementItem extends AbstractEntity {
  termOrCondition?: AgreementTermOrCondition[];
}
