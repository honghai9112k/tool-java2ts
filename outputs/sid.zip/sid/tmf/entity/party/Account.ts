export interface Account extends AbstractEntity {
  taxExemption?: TaxExemptionCertificate[];
  accountType?: string;
  contact?: Contact[];
  creditLimit?: Money;
  accountRelationship?: AccountRelationship[];
  state?: string;
  relatedParty?: RelatedParty[];
  accountBalance?: AccountBalance[];
}
