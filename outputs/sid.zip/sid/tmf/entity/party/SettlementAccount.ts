export interface SettlementAccount extends PartyAccount {
}
