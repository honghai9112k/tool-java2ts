export interface AgreementRelationship extends EntityRel {
  code?: string;
}
