export interface AgreementSpecification extends AbstractEntity {
  isBundle?: boolean;
  relatedParty?: RelatedParty[];
  specificationCharacteristic?: CharacteristicSpecification[];
  specificationRelationship?: AgreementSpecificationRelationship[];
  attachment?: AttachmentRefOrValue[];
  externalIdentifier?: ExternalIdentifier[];
  category?: EntityRef;
}
