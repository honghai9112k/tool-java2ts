export interface FinancialAccount extends Account {
}
