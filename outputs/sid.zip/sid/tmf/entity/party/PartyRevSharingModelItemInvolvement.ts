export interface PartyRevSharingModelItemInvolvement extends AbstractEntity {
  offeringPrice?: PartyRevSharingModelInvolPrice[];
  productOffering?: EntityRef[];
  agreementItem?: EntityRef[];
}
