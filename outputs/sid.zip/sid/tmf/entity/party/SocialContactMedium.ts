export interface SocialContactMedium extends ContactMedium {
}
