export interface Skill {
  code?: string;
  skillCode?: string;
  skillName?: string;
  evaluatedLevel?: string;
  comment?: string;
  validFor?: TimePeriod;
}
