export interface PhoneContactMedium extends ContactMedium {
}
