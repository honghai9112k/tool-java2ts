export interface Supplier extends PartyRole {
}
