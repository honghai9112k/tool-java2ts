export interface AgreementItemRef extends EntityRef {
  agreementItemId?: string;
}
