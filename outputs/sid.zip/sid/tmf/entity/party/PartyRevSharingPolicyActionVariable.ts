export interface PartyRevSharingPolicyActionVariable extends AbstractEntity {
  policyAction?: EntityRef;
  value?: string;
  policyActionVariable?: EntityRef;
}
