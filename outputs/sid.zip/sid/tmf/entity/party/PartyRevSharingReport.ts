export interface PartyRevSharingReport extends AbstractEntity {
  cdrTransaction?: EntityRef;
  money?: Money;
  partyRevSharingReportItem?: PartyRevSharingReportItem[];
  partyRevSharingModel?: EntityRef;
  createDate?: Date;
}
