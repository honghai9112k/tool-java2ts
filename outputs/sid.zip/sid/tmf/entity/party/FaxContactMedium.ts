export interface FaxContactMedium extends ContactMedium {
}
