export interface OrganizationChildRelationship extends EntityRel {
  code?: string;
  organization?: EntityRef;
}
