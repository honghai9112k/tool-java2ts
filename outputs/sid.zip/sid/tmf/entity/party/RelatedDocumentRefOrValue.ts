export interface RelatedDocumentRefOrValue extends AbstractEntity {
  role?: string;
  document?: DocumentRefOrValue;
}
