export interface PartyRevSharingPolicyConditionVariable extends AbstractEntity {
  policyConditionVariable?: EntityRef;
  value?: string;
  policyCondition?: EntityRef;
}
