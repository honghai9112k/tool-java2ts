export interface Agreement extends AbstractEntity {
  agreementType?: string;
  agreementPeriod?: TimePeriod;
  agreementSpecification?: EntityRef;
  relatedParty?: RelatedParty[];
  initialDate?: Date;
  characteristic?: Characteristic[];
  agreementRelationship?: AgreementRelationship[];
  agreementAuthorization?: AgreementAuthorization[];
  externalIdentifier?: ExternalIdentifier[];
  completionDate?: TimePeriod;
  statementOfIntent?: string;
  agreementItem?: AgreementItem[];
  engagedParty?: EntityRef[];
  relatedDocument?: EntityRef[];
  status?: string;
}
