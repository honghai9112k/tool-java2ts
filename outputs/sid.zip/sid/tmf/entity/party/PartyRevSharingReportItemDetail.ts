export interface PartyRevSharingReportItemDetail extends AbstractEntity {
  product?: EntityRef[];
  partyRevSharingAlgorithm?: EntityRef[];
  money?: Money;
  productOffering?: EntityRef;
  productOfferingPrice?: EntityRef;
  partyRevSharingModelInvolPrice?: EntityRef;
  status?: string;
  createDate?: Date;
}
