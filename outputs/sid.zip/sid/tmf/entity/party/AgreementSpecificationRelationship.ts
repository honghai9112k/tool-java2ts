export interface AgreementSpecificationRelationship extends EntityRel {
  code?: string;
}
