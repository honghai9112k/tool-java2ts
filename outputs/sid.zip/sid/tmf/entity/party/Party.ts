export interface Party extends AbstractEntity {
  externalReference?: ExternalIdentifier[];
  taxExemptionCertificate?: TaxExemptionCertificate[];
  partyCharacteristic?: Characteristic[];
  contactMedium?: ContactMedium[];
  relatedParty?: RelatedParty[];
  creditRating?: PartyCreditProfile[];
}
