export interface PartyInteraction extends AbstractEntity {
  reason?: string;
  note?: Note[];
  interactionRelationship?: InteractionRelationship[];
  creationDate?: Date;
  relatedParty?: RelatedParty[];
  statusChangeDate?: Date;
  interactionDate?: TimePeriod;
  interactionItem?: InteractionItem[];
  attachment?: AttachmentRefOrValue[];
  relatedChannel?: RelatedChannel[];
  externalIdentifier?: ExternalIdentifier[];
  direction?: string;
  status?: string;
}
