export interface BusinessPartner extends PartyRole {
}
