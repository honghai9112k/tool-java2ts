export interface PartyRefOrPartyRoleRef extends EntityOrOtherEntity {
  partyId?: string;
  partyName?: string;
}
