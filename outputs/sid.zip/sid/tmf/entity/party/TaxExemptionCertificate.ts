export interface TaxExemptionCertificate extends AbstractEntity {
  certificateNumber?: string;
  issuingJurisdiction?: string;
  reason?: string;
  attachment?: AttachmentRefOrValue;
  taxDefinition?: TaxDefinition[];
}
