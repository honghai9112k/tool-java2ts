export interface Organization extends Party {
  organizationType?: string;
  nameType?: string;
  tradingName?: string;
  existsDuring?: TimePeriod;
  organizationChildRelationship?: OrganizationChildRelationship[];
  isHeadOffice?: boolean;
  isLegalEntity?: boolean;
  otherName?: OtherNameOrganization[];
  organizationIdentification?: OrganizationIdentification[];
  status?: string;
  organizationParentRelationship?: OrganizationParentRelationship;
}
